/**
 * Strict free-parking classification shared by polygon + roadside layers.
 * Green ("Tasuta") is reserved for unlimited free public parking only —
 * no time limit, no parking clock. Clock-limited free stays → "Kellaga".
 */

/** Unlimited free — Tasuta (strict green). */
export const PARKING_COLOR_FREE = '#00FF00'
/** Unclassified / private / unknown — not free public parking. */
export const PARKING_COLOR_UNKNOWN = '#9CA3AF'
/** Legacy gray from older builds — still treated as unknown for paint/filters. */
export const PARKING_COLOR_UNKNOWN_LEGACY = '#A0AEC0'

export function isUnknownPaintColor(color: unknown): boolean {
  const c = String(color || '').trim().toUpperCase()
  return (
    c === PARKING_COLOR_UNKNOWN.toUpperCase() ||
    c === PARKING_COLOR_UNKNOWN_LEGACY.toUpperCase()
  )
}
/** Paid parking — Tasuline (strict red). */
export const PARKING_COLOR_PAID = '#FF0000'
/** Clock / time-limited free — Kellaga (strict yellow). */
export const PARKING_COLOR_TIMED = '#FFCC00'

/** Spot-like fields used by Tasuta / Kellaga filter helpers. */
export type FreeClockFields = {
  layer?: string
  type?: string
  free_minutes?: number
  price_per_hour?: number
  verified_free?: boolean
  timeLimit?: string
  zone_code?: string
  badge?: string
  name?: string
  desc?: string
}

function strField(v: unknown): string {
  return v == null ? '' : String(v).trim()
}

/** Parse OSM maxstay / duration strings into minutes. */
export function parseMaxstayMinutes(maxstay: unknown): number {
  const raw = strField(maxstay)
  if (!raw) return 0
  const s = raw.toLowerCase()
  if (s === 'unlimited' || s === 'no') return 0
  const hours = s.match(/^(\d+(?:\.\d+)?)\s*h(?:ours?)?$/)
  if (hours) return Math.round(parseFloat(hours[1]) * 60)
  const mins = s.match(/^(\d+)\s*m(?:in(?:utes?)?)?$/)
  if (mins) return parseInt(mins[1], 10)
  const combo = s.match(/(\d+(?:\.\d+)?)\s*hours?/)
  if (combo) return Math.round(parseFloat(combo[1]) * 60)
  const comboM = s.match(/(\d+)\s*minutes?/)
  if (comboM) return parseInt(comboM[1], 10)
  // "30 minutes @ Mo-Fr …" / bare number
  const leading = s.match(/^(\d+(?:\.\d+)?)/)
  if (leading && /min/.test(s)) return Math.round(parseFloat(leading[1]))
  return 0
}

/**
 * Detect clock / time-limit signals from OSM + curated text fields.
 * Returns inferred free-window minutes (0 if none).
 */
export function extractClockMinutes(
  ...parts: Array<unknown>
): number {
  let mins = 0
  const texts: string[] = []
  for (const part of parts) {
    if (part && typeof part === 'object' && !Array.isArray(part)) {
      const rec = part as Record<string, unknown>
      for (const [k, v] of Object.entries(rec)) {
        if (
          k === 'maxstay' ||
          k.startsWith('maxstay:') ||
          k.startsWith('maxstay:conditional')
        ) {
          mins = mins || parseMaxstayMinutes(v)
        }
        if (
          k === 'name' ||
          k === 'description' ||
          k === 'desc' ||
          k === 'timeLimit' ||
          k === 'badge' ||
          k === 'zone_code' ||
          k === 'zone' ||
          k === 'rules' ||
          k.includes('parking:condition')
        ) {
          texts.push(strField(v))
        }
      }
    } else {
      texts.push(strField(part))
    }
  }
  const text = texts.join(' ')
  if (!mins) {
    const minMatch = text.match(/\b(\d{1,3})\s*min(?:utes?)?\b/i)
    if (minMatch) mins = parseInt(minMatch[1], 10)
  }
  if (!mins) {
    const hourMatch = text.match(/\b(\d+(?:\.\d+)?)\s*h(?:ours?|undi)?\b/i)
    if (hourMatch) mins = Math.round(parseFloat(hourMatch[1]) * 60)
  }
  if (
    !mins &&
    /parkimiskell|ajapiirang|\bkellaga\b|\bdisc\b|parking\s*clock/i.test(text)
  ) {
    mins = 15
  }
  return mins
}

/** True when text/tags clearly indicate a parking-clock / time limit. */
export function hasClockKeyword(...parts: Array<unknown>): boolean {
  if (extractClockMinutes(...parts) > 0) return true
  const text = parts.map(strField).join(' ')
  return /parkimiskell|ajapiirang|\bkellaga\b|\bdisc\b|\bKELL\b/i.test(text)
}

/**
 * Unlimited free public parking — the only features that belong in "Tasuta".
 * Must be free (€0), have no free-minute window, and not be on the timed layer.
 * Never trust verified_free alone on paid / brand / municipal operator layers.
 */
export function isUnlimitedFreeParking(p: FreeClockFields): boolean {
  const layer = String(p.layer || '')
  const mins = Number(p.free_minutes ?? 0)
  const price = Number(p.price_per_hour ?? 0)
  if (mins > 0) return false
  if (price > 0) return false
  if (layer === 'timed') return false
  if (p.type === 'timed') return false
  if (hasClockKeyword(p.timeLimit, p.badge, p.name, p.desc, p.zone_code)) {
    return false
  }
  // Paid brand / municipal / loading layers are never unlimited free —
  // even when OSM wrongly sets fee=no (common in Kesklinn / stadium lots).
  if (
    layer === 'municipal' ||
    layer === 'europark' ||
    layer === 'snabb' ||
    layer === 'citypark' ||
    layer === 'uhisteenused' ||
    layer === 'parkit' ||
    layer === 'park_ride' ||
    layer === 'loading'
  ) {
    return false
  }
  if (hasExplicitPaidZoneCode(p.zone_code)) return false
  if (layer === 'free_street') return true
  // verified_free only counts on an explicitly free layer / type
  if (p.verified_free && (layer === 'free_street' || p.type === 'free' || !layer)) {
    return true
  }
  if (p.type === 'free' && layer !== 'municipal') return true
  return false
}

/**
 * Tallinn municipal zones that officially allow free minutes with a parking
 * clock (kellaga) — even when an hourly rate applies after the free window.
 */
const TALLINN_CLOCK_ZONES = new Set([
  'KESKLINN',
  'VANALINN',
  'SÜDALINN',
  'SUDALINN',
  'PIRITA',
])

export function isTallinnClockZone(zoneRaw?: string | null): boolean {
  const z = String(zoneRaw || '')
    .trim()
    .toUpperCase()
  if (!z) return false
  if (TALLINN_CLOCK_ZONES.has(z)) return true
  // ASCII fallback (SUDALINN) + bare area names from display titles
  const ascii = z
    .replace(/Ü/g, 'U')
    .replace(/Ä/g, 'A')
    .replace(/Ö/g, 'O')
    .replace(/Õ/g, 'O')
  if (TALLINN_CLOCK_ZONES.has(ascii)) return true
  // Zone titles only: "Kesklinn", "Südalinn (AS Ühisteenused)".
  // Do NOT match place names like "Pirita Pargi & Reisi" (free P&R).
  return /^(KESKLINN|VANALINN|S[UÜ]DALINN|PIRITA)(\s*\(.*\))?$/i.test(z)
}

/**
 * Time-limited / parking-clock free parking — "Kellaga" filter.
 * ANY spot with a free-clock window belongs here, including Tallinn paid
 * zones (Kesklinn / Südalinn / Vanalinn / Pirita) that allow 15 min free
 * with a disc before the hourly rate starts.
 */
export function isClockLimitedParking(p: FreeClockFields): boolean {
  const layer = String(p.layer || '')
  const mins = Number(p.free_minutes ?? 0)
  const zone = String(p.zone_code || '').toUpperCase()
  const badge = String(p.badge || '').toUpperCase()

  // Explicit free-clock window beats paid €/h (Tallinn municipal rules)
  if (Number.isFinite(mins) && mins > 0) return true

  if (layer === 'timed' || p.type === 'timed') return true
  if (zone === 'KELL' || badge === 'KELL') return true

  // Official Tallinn clock zones — include even if free_minutes was dropped
  if (isTallinnClockZone(zone) || isTallinnClockZone(badge)) return true
  if (isTallinnClockZone(p.name)) return true

  if (
    hasClockKeyword(
      p.timeLimit,
      p.badge,
      p.name,
      p.desc,
      p.zone_code,
    )
  ) {
    return true
  }
  return false
}

/**
 * Mutually exclusive filter bucket for map chips + “Lähimad parklad”.
 * Priority: free → timed → paid → other.
 * Timed lots (incl. Tallinn 15 min free + hourly after) are NEVER “paid”
 * for chip filters — they belong only under Kellaga.
 */
export type ParkingFilterCategory = 'free' | 'timed' | 'paid' | 'other'

export function getParkingFilterCategory(
  p: FreeClockFields,
): ParkingFilterCategory {
  if (isUnlimitedFreeParking(p)) return 'free'
  if (isClockLimitedParking(p)) return 'timed'

  const layer = String(p.layer || '')
  const price = Number(p.price_per_hour ?? 0)
  if (price > 0 || String(p.badge || '').toUpperCase() === 'PAID') {
    return 'paid'
  }
  if (hasExplicitPaidZoneCode(p.zone_code)) return 'paid'
  if (
    layer === 'europark' ||
    layer === 'snabb' ||
    layer === 'citypark' ||
    layer === 'uhisteenused' ||
    layer === 'parkit' ||
    layer === 'park_ride' ||
    layer === 'loading'
  ) {
    return 'paid'
  }
  return 'other'
}

/** Detail-sheet headline for clock-limited free parking. */
export function clockFreeHeadline(freeMinutes: number): string {
  const mins = Math.max(0, Math.round(freeMinutes))
  if (mins > 0) return `Kellaga - ${mins} min`
  return 'Kellaga'
}

/** Known city / municipal operators (not private yards). */
export function isKnownCityOperator(operator?: string | null): boolean {
  const op = String(operator || '')
    .trim()
    .toLowerCase()
  if (!op) return false
  return (
    op.includes('tallinna linn') ||
    op.includes('tallinn') ||
    op.includes('pärnu linn') ||
    op.includes('parnu linn') ||
    op.includes('tartu linn') ||
    /\blinn\b/.test(op)
  )
}

/**
 * Explicit paid operator zone codes (EP9, X56, SB7, YT…, PKESK…).
 * Generic ZONE / KELL / FREE are not paid zone codes.
 */
export function hasExplicitPaidZoneCode(zoneRaw?: string | null): boolean {
  const z = String(zoneRaw || '')
    .trim()
    .toUpperCase()
  if (!z) return false
  if (/^(ZONE|UNKNOWN|KELL|FREE|PAID|P|EV|INVA|LOAD)$/.test(z)) return false
  if (/^(PKESK|PRAND)$/.test(z)) return true
  if (/^(EP|X|SB|YT|CP|PK|UT)\d+/i.test(z)) return true
  if (/^P\+\d+$/i.test(z)) return true
  // Named municipal zone refs that are not the generic placeholder
  if (/^[A-ZÄÖÜÕ]{1,4}\d{1,4}[A-ZÄÖÜÕ0-9]*$/i.test(z) && z !== 'ZONE') {
    return true
  }
  return false
}

/**
 * Compact category badge for the detail card header.
 * e.g. "Kellaga - 15 min", "Tasuta", "EP9", "Tasuline".
 */
export function categoryBadgeLabel(
  p: FreeClockFields & { operator?: string; color?: string },
): string {
  if (isUnlimitedFreeParking(p)) return 'Tasuta'
  if (isClockLimitedParking(p)) {
    const mins = Math.max(0, Math.round(Number(p.free_minutes ?? 0)))
    return mins > 0 ? `Kellaga - ${mins} min` : 'Kellaga'
  }
  const zone = String(p.zone_code || '').trim()
  const price = Number(p.price_per_hour ?? 0)
  if (price > 0 || hasExplicitPaidZoneCode(zone)) {
    if (zone && !/^(ZONE|UNKNOWN|PAID)$/i.test(zone)) return zone
    return 'Tasuline'
  }
  if (isUnclassifiedParking(p)) return 'Hind teadmata'
  if (zone && !/^(ZONE|UNKNOWN)$/i.test(zone)) return zone
  return 'Hind teadmata'
}

/**
 * Strict category paint for map geometry (Kõik / filters):
 * Green = unlimited free · Yellow = clock-limited · Red = paid · Gray = other.
 * Uses the same exclusive buckets as map chips + “Lähimad parklad”.
 */
export function categoryPaintColor(p: FreeClockFields): string {
  switch (getParkingFilterCategory(p)) {
    case 'free':
      return PARKING_COLOR_FREE
    case 'timed':
      return PARKING_COLOR_TIMED
    case 'paid':
      return PARKING_COLOR_PAID
    default:
      return PARKING_COLOR_UNKNOWN
  }
}

const KNOWN_OPERATOR_LAYERS = new Set([
  'europark',
  'snabb',
  'citypark',
  'uhisteenused',
  'parkit',
  'ev',
  'inva',
  'loading',
  'park_ride',
  'free_street',
  'timed',
])

/**
 * Grey / private / unclassified parking — no clear operator pricing.
 * Used by the "Other / Private" filter and detail-panel warning.
 *
 * Never marks Kellaga / Tasuta / priced city lots as unclassified —
 * including Tallinna Linn operator with a clock window (e.g. 15 min).
 */
export function isUnclassifiedParking(p: {
  layer?: string
  verified_free?: boolean
  price_per_hour?: number
  free_minutes?: number
  zone_code?: string
  operator?: string
  color?: string
  type?: string
  timeLimit?: string
  name?: string
  desc?: string
  badge?: string
}): boolean {
  const layer = String(p.layer || '')
  if (p.verified_free || layer === 'free_street') return false
  if (KNOWN_OPERATOR_LAYERS.has(layer) && layer !== 'municipal') return false
  if (layer === 'timed') return false
  // Kellaga / clock rules (maxstay, Parkimiskellaga, free_minutes…) never "Muud / Era"
  if (
    isClockLimitedParking({
      layer,
      type: p.type,
      free_minutes: p.free_minutes,
      price_per_hour: p.price_per_hour,
      zone_code: p.zone_code,
      verified_free: p.verified_free,
      timeLimit: p.timeLimit,
      name: p.name,
      desc: p.desc,
      badge: p.badge,
    })
  ) {
    return false
  }
  // Paid rate or explicit paid zone code → Tasuline
  if ((p.price_per_hour ?? 0) > 0) return false
  if (hasExplicitPaidZoneCode(p.zone_code)) return false
  // Known city operator with any clock / free-minute signal → not private
  const mins = Number(p.free_minutes ?? 0)
  if (isKnownCityOperator(p.operator) && mins > 0) return false
  if (
    isKnownCityOperator(p.operator) &&
    hasClockKeyword(p.timeLimit, p.name, p.desc, p.badge, p.zone_code)
  ) {
    return false
  }
  const zone = String(p.zone_code || '').toUpperCase()
  const op = String(p.operator || '')
  if (isUnknownPaintColor(p.color)) return true
  if (zone === 'ZONE' || zone === '' || zone === 'UNKNOWN') return true
  if (!op || op === 'Unknown') return true
  // Municipal with no fee / clock / price signal falls into the grey bucket
  return layer === 'municipal'
}
function str(v: unknown): string {
  return v == null ? '' : String(v).trim()
}

/** Access values that are never shown as free public parking. */
const BLOCKED_ACCESS = new Set([
  'private',
  'customers',
  'permit',
  'residents',
  'employees',
  'no',
  'destination',
  'bus',
  'taxi',
])

export function isPaidFeeTag(feeRaw: unknown, chargeRaw?: unknown): boolean {
  const fee = str(feeRaw).toLowerCase()
  if (!fee && !str(chargeRaw)) return false
  if (fee === 'no' || fee === 'free') return false
  if (fee === 'yes' || fee === 'private' || fee.includes('€') || fee.includes('eur')) return true
  if (str(chargeRaw)) return true
  // Numeric / schedule fee strings from OSM
  if (/\d/.test(fee) && (fee.includes('€') || fee.includes('eur') || fee.includes('/'))) return true
  return false
}

export function isExplicitFreeFee(feeRaw: unknown): boolean {
  const fee = str(feeRaw).toLowerCase()
  return fee === 'no' || fee === 'free'
}

export function isFreeZoneCode(zoneRaw: unknown): boolean {
  return str(zoneRaw).toUpperCase() === 'FREE'
}

/**
 * Verified free public parking — the only features allowed to use green.
 *
 * True when an explicit free signal is present:
 *   - fee === 'no' | 'free'
 *   - zone / zone_code === 'FREE'
 *   - curated rules === 'free'
 * and access is not private/customers/restricted.
 *
 * access=yes/public alone is NOT enough (avoids painting paid public lots green).
 * Callers MUST run Tallinn zone / Arena overrides first — raw OSM fee=no inside
 * Kesklinn or on stadium P1–P6 is not verified free.
 */
export function isVerifiedFreeParking(p: {
  fee?: unknown
  access?: unknown
  zone?: unknown
  zone_code?: unknown
  ref?: unknown
  rules?: unknown
  charge?: unknown
  enriched_as?: unknown
  enriched_from_zone?: unknown
}): boolean {
  // Zone / stadium enrichment already decided this is not unlimited free
  const enriched = str(p.enriched_as).toLowerCase()
  if (
    enriched === 'tallinn_paid_zone' ||
    enriched === 'arena_stadium_paid' ||
    str(p.enriched_from_zone)
  ) {
    return false
  }
  // Build-time "free_outside_zones" forced fee=no on unmarked lots — that is
  // NOT verified unlimited free. Leave those gray until OSM/official tags say so.
  if (enriched === 'free_outside_zones') {
    return false
  }
  if (str(p.rules).toLowerCase() === 'paid') return false

  const access = str(p.access).toLowerCase()
  if (access && BLOCKED_ACCESS.has(access)) return false

  if (isPaidFeeTag(p.fee, p.charge)) return false

  const rules = str(p.rules).toLowerCase()
  if (rules === 'free') return true

  const zone = p.zone ?? p.zone_code ?? p.ref
  if (isFreeZoneCode(zone)) return true

  if (isExplicitFreeFee(p.fee)) return true

  // Public access with an explicit free fee already handled above.
  // access=yes|public without fee/zone free tags → not verified free.
  return false
}

/** Public / yes access (optional gate helpers for UI copy). */
export function isPublicAccess(accessRaw: unknown): boolean {
  const access = str(accessRaw).toLowerCase()
  return access === 'yes' || access === 'public' || access === 'permissive' || access === ''
}

export type ParkingExclusionReason =
  | 'private_access'
  | 'private_parking'
  | 'underground'

/** Commercial / brand operators whose underground garages stay on the map. */
function isCommercialParkingOperator(operatorRaw: unknown): boolean {
  const op = str(operatorRaw).toLowerCase()
  if (!op) return false
  return (
    op.includes('europark') ||
    op.includes('euro park') ||
    op.includes('snabb') ||
    op.includes('citypark') ||
    op.includes('city park') ||
    op.includes('parkit') ||
    op.includes('ühisteenused') ||
    op.includes('uhisteenused') ||
    op.includes('q-park') ||
    op.includes('apcoa')
  )
}

/** Numeric OSM `layer=*` (building level). Ignores app layer keys like "europark". */
export function osmLevelLayer(layerRaw: unknown): number | null {
  if (typeof layerRaw === 'number' && Number.isFinite(layerRaw)) return layerRaw
  const s = str(layerRaw)
  if (!s || !/^-?\d+(\.\d+)?$/.test(s)) return null
  const n = Number(s)
  return Number.isFinite(n) ? n : null
}

/**
 * Map-canvas exclusion — drop private yards / resident-only and phantom
 * underground building parking. Public/commercial garages are kept.
 *
 * Returns a reason string when the feature must be purged, otherwise null.
 */
export function getParkingExclusionReason(
  p: Record<string, unknown>,
): ParkingExclusionReason | null {
  const access = str(p.access).toLowerCase()
  const parking = str(p.parking).toLowerCase()
  const location = str(p.location).toLowerCase()

  // Resident-only & private yards — hard exclude (never gray, never green)
  if (
    access === 'private' ||
    access === 'destination' ||
    access === 'residents'
  ) {
    return 'private_access'
  }
  if (parking === 'private' || parking === 'residential') {
    return 'private_parking'
  }

  const level = osmLevelLayer(p.layer)
  const isUnderground =
    location === 'underground' ||
    parking === 'underground' ||
    parking === 'garage' ||
    (level != null && level < 0)

  if (!isUnderground) return null

  // Keep explicitly public / commercial underground garages
  if (access === 'public' || access === 'yes') return null
  if (isCommercialParkingOperator(p.operator)) return null

  return 'underground'
}

export function shouldExcludeParkingFeature(p: Record<string, unknown>): boolean {
  return getParkingExclusionReason(p) != null
}

export type ParkingPrepPurgeStats = {
  input: number
  kept: number
  purgedTotal: number
  purged: Record<ParkingExclusionReason, number>
}

export function emptyPurgeStats(): ParkingPrepPurgeStats {
  return {
    input: 0,
    kept: 0,
    purgedTotal: 0,
    purged: {
      private_access: 0,
      private_parking: 0,
      underground: 0,
    },
  }
}

export function tallyParkingPurge(
  features: Array<{ properties?: Record<string, unknown> | null } | null | undefined>,
): ParkingPrepPurgeStats {
  const stats = emptyPurgeStats()
  for (const f of features) {
    stats.input++
    const reason = getParkingExclusionReason(f?.properties ?? {})
    if (reason) {
      stats.purged[reason]++
      stats.purgedTotal++
    } else {
      stats.kept++
    }
  }
  return stats
}
