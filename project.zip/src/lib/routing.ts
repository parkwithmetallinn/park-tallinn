/**
 * Dual-leg routing via same-origin proxies (Vite / Vercel).
 *
 * App coords are [lat, lng]; OSRM wants lng,lat in the URL and GeoJSON.
 *
 * Providers (community fair-use — replace for heavy production with Mapbox
 * Directions, Valhalla, OpenRouteService, or a self-hosted OSRM):
 *   car:  /api/route-car  → routing.openstreetmap.de/routed-car
 *         fallback        → router.project-osrm.org (car only)
 *   foot: /api/route-foot → routing.openstreetmap.de/routed-foot
 *         (pedestrian profile: sidewalks, footways, crossings — not roads-only)
 */

import { distanceMeters } from './geo'
import { apiUrl } from './apiBase'

export type LonLat = [number, number]

/** @deprecated Prefer RouteMode */
export type RouteProfile = 'driving' | 'foot'

export type RouteMode = 'driving' | 'walking'

/** App-facing route geometry — [lat, lng] for drawing helpers / camera. */
export type RouteResult = {
  coords: [number, number][]
  distanceMeters: number
  durationSeconds: number
  /**
   * True when geometry includes a short sidewalk-snap connector (or a last-resort
   * corridor). Never a building-crossing straight line between parking ↔ house.
   */
  isFallback?: boolean
  /** @deprecated Prefer RouteMode on the caller */
  profile?: RouteProfile
}

/** Drive to parking + optional walk from parking to the searched destination. */
export type RoutePlan = {
  /** Driving leg: user → parking (null if drive failed) */
  drive: RouteResult | null
  /** Walking leg: parking → destination (null when no separate destination) */
  walk: RouteResult | null
  parking: [number, number]
  destination: [number, number] | null
  /** True when walk distance warrants a "Pikk jalutuskäik" chip */
  longWalk?: boolean
  /** Toast hint when walk router failed and fallback was used */
  walkFailed?: boolean
}

/**
 * App bundle used by MapView / summary card.
 * Extends RoutePlan with a display label for the parking target.
 */
export type NavRouteBundle = RoutePlan & {
  /** Label for the parking / destination target */
  label: string
  /** @deprecated Alias of destination */
  house: [number, number]
}

/** @deprecated Prefer RouteResult — kept for any leftover call sites. */
export interface DrivingRoute {
  coordinates: LonLat[]
  callouts: Array<{ id: string; name: string; lng: number; lat: number }>
  distanceMeters: number
  durationSeconds: number
  bearing: number
}

interface OsrmResponse {
  code: string
  message?: string
  routes?: Array<{
    distance: number
    duration: number
    geometry?: { coordinates?: LonLat[] }
  }>
}

interface OsrmNearestResponse {
  code: string
  waypoints?: Array<{
    location?: LonLat
    distance?: number
    name?: string
  }>
}

const routeCache = new Map<string, RouteResult>()
const nearestCache = new Map<string, [number, number]>()

const REQUEST_TIMEOUT_MS = 10_000
/** Skip walking request when parking is essentially at the destination. */
const WALK_SKIP_M = 30
/** Warn when the walk is long (≥ 1.5 km) or a big detour vs straight line. */
const LONG_WALK_M = 1_500
const LONG_WALK_DETOUR_RATIO = 4
const LONG_WALK_DETOUR_MIN_M = 800
/** Bridge tiny gaps between drive end and walk start. */
const CONNECTOR_GAP_M = 5
/**
 * Only stitch marker→sidewalk with a short connector. Longer gaps stay on the
 * snapped foot network so we never draw through buildings/courtyards.
 */
const MAX_STITCH_M = 40
/**
 * Mid-segment without foot geometry may only be this short. Longer snap→snap
 * chords cut through buildings / vehicle-only roads and must be rejected.
 */
const MAX_MID_CHORD_M = 25
/** OSRM radiuses (meters) to snap endpoints onto the walkable graph. */
const WALK_RADII_M = [80, 150, 300, 500] as const
/** Pedestrian OSRM profiles on the routed-foot instance (same graph). */
const FOOT_PROFILES = ['foot', 'walking', 'pedestrian'] as const

function round5(n: number) {
  return Math.round(n * 1e5) / 1e5
}

function cacheKey(
  from: [number, number],
  to: [number, number],
  mode: RouteMode,
) {
  return `${mode}:${round5(from[0])},${round5(from[1])}->${round5(to[0])},${round5(to[1])}`
}

function nearestKey(point: [number, number]) {
  return `near:${round5(point[0])},${round5(point[1])}`
}

/** Initial bearing from A → B in degrees (0 = north, clockwise). */
export function bearingDegrees(
  fromLat: number,
  fromLng: number,
  toLat: number,
  toLng: number,
): number {
  const φ1 = (fromLat * Math.PI) / 180
  const φ2 = (toLat * Math.PI) / 180
  const Δλ = ((toLng - fromLng) * Math.PI) / 180
  const y = Math.sin(Δλ) * Math.cos(φ2)
  const x =
    Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ)
  return ((Math.atan2(y, x) * 180) / Math.PI + 360) % 360
}

export function formatDuration(seconds: number): string {
  const s = Math.max(0, Math.round(seconds))
  const mins = Math.round(s / 60)
  if (mins < 60) return `${Math.max(1, mins)} min`
  const h = Math.floor(mins / 60)
  const m = mins % 60
  return m === 0 ? `${h} h` : `${h} h ${m} min`
}

/** Rough urban drive ETA for search suggestion meta (no OSRM round-trip). */
export function estimateDriveMinutes(meters: number): number {
  const km = Math.max(0, meters) / 1000
  // ~32 km/h city average → minutes
  return Math.max(1, Math.round((km / 32) * 60))
}

/** Convert RouteResult [lat,lng][] → GeoJSON LineString [lng,lat][]. */
export function routeCoordsToLngLat(coords: [number, number][]): LonLat[] {
  return coords.map(([lat, lng]) => [lng, lat])
}

function withTimeoutSignal(
  outer?: AbortSignal,
  ms = REQUEST_TIMEOUT_MS,
): { signal: AbortSignal; clear: () => void } {
  const ctrl = new AbortController()
  const onAbort = () => ctrl.abort()
  if (outer) {
    if (outer.aborted) ctrl.abort()
    else outer.addEventListener('abort', onAbort, { once: true })
  }
  const timer = window.setTimeout(() => ctrl.abort(), ms)
  return {
    signal: ctrl.signal,
    clear: () => {
      window.clearTimeout(timer)
      outer?.removeEventListener('abort', onAbort)
    },
  }
}

function pathLengthMeters(coords: [number, number][]): number {
  let sum = 0
  for (let i = 1; i < coords.length; i++) {
    const a = coords[i - 1]!
    const b = coords[i]!
    sum += distanceMeters(a[0], a[1], b[0], b[1])
  }
  return sum
}

function walkDurationSeconds(distM: number): number {
  // ~1.4 m/s urban walking pace
  return Math.max(60, Math.round(distM / 1.4))
}

function interpolateLatLng(
  a: [number, number],
  b: [number, number],
  t: number,
): [number, number] {
  return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]
}

function pushUniqueCoord(coords: [number, number][], p: [number, number]) {
  const last = coords[coords.length - 1]
  if (
    !last ||
    distanceMeters(last[0], last[1], p[0], p[1]) > 0.4
  ) {
    coords.push(p)
  }
}

/**
 * True when geometry is essentially a geodesic chord (buildings / yards).
 * Real foot routes have many vertices and detour around the block.
 */
function isChordLike(coords: [number, number][]): boolean {
  if (coords.length < 2) return true
  const straight = distanceMeters(
    coords[0]![0],
    coords[0]![1],
    coords[coords.length - 1]![0],
    coords[coords.length - 1]![1],
  )
  if (coords.length === 2) return straight > MAX_MID_CHORD_M
  const pathM = pathLengthMeters(coords)
  if (pathM < 1) return true
  // Near-geodesic with almost no vertices → illegally cutting through blocks
  if (
    coords.length <= 4 &&
    straight > MAX_MID_CHORD_M &&
    pathM / straight < 1.08
  ) {
    return true
  }
  return false
}

function dedupeWaypoints(points: [number, number][]): [number, number][] {
  const out: [number, number][] = []
  for (const p of points) {
    const last = out[out.length - 1]
    if (
      !last ||
      distanceMeters(last[0], last[1], p[0], p[1]) > 8
    ) {
      out.push(p)
    }
  }
  return out
}

/**
 * Route through sidewalk-snapped midpoints so long legs follow the foot graph
 * even when a direct OSRM pair fails (gaps, private courts, missing links).
 */
async function fetchFootViaSidewalkMids(
  from: [number, number],
  to: [number, number],
  signal?: AbortSignal,
): Promise<RouteResult | null> {
  const dist = distanceMeters(from[0], from[1], to[0], to[1])
  if (dist < 60) return null

  const fractions =
    dist > 900 ? [0.25, 0.5, 0.75] : dist > 350 ? [0.33, 0.66] : [0.5]
  const mids = await Promise.all(
    fractions.map((t) =>
      snapToWalkNetwork(interpolateLatLng(from, to, t), signal),
    ),
  )
  const waypoints = dedupeWaypoints([from, ...mids, to])
  if (waypoints.length < 3) return null

  // Single multi-waypoint request on the foot graph
  try {
    const routed = await fetchFootRouteMulti(waypoints, signal, 200)
    if (!isChordLike(routed.coords)) return routed
  } catch (e) {
    if ((e as Error).name === 'AbortError') throw e
  }

  // Stitch leg-by-leg if the multi request fails (raw only — no recursion)
  const stitched: [number, number][] = []
  let totalDist = 0
  let totalDur = 0
  for (let i = 0; i < waypoints.length - 1; i++) {
    const a = waypoints[i]!
    const b = waypoints[i + 1]!
    const legStraight = distanceMeters(a[0], a[1], b[0], b[1])
    let leg: RouteResult | null = null
    for (const radius of WALK_RADII_M) {
      try {
        const candidate = await fetchFootRouteRaw(a, b, signal, radius)
        if (!isChordLike(candidate.coords)) {
          leg = candidate
          break
        }
      } catch (e) {
        if ((e as Error).name === 'AbortError') throw e
      }
    }
    if (leg) {
      for (const p of leg.coords) pushUniqueCoord(stitched, p)
      totalDist += leg.distanceMeters
      totalDur += leg.durationSeconds
    } else if (legStraight <= MAX_MID_CHORD_M) {
      // Tiny sidewalk hop only — never a long illegal chord
      pushUniqueCoord(stitched, a)
      pushUniqueCoord(stitched, b)
      totalDist += legStraight
      totalDur += walkDurationSeconds(legStraight)
    } else {
      // Skip the illegal span; keep whatever network path we already have
      pushUniqueCoord(stitched, a)
    }
  }
  pushUniqueCoord(stitched, to)
  if (stitched.length < 2 || isChordLike(stitched)) return null
  return {
    coords: stitched,
    distanceMeters: totalDist > 0 ? totalDist : pathLengthMeters(stitched),
    durationSeconds:
      totalDur > 0 ? totalDur : walkDurationSeconds(pathLengthMeters(stitched)),
    profile: 'foot',
  }
}

/**
 * Last-resort walk geometry: parking → nearest sidewalk → foot network →
 * destination sidewalk → destination. Never a building-crossing mid chord.
 */
async function sidewalkCorridorFallback(
  from: [number, number],
  to: [number, number],
  signal?: AbortSignal,
): Promise<RouteResult> {
  const [snapFrom, snapTo] = await Promise.all([
    snapToWalkNetwork(from, signal),
    snapToWalkNetwork(to, signal),
  ])

  let mid: [number, number][] | null = null

  // Prefer real foot geometry with growing snap radiuses
  for (const radius of WALK_RADII_M) {
    try {
      const routed = await fetchFootRouteRaw(snapFrom, snapTo, signal, radius)
      if (!isChordLike(routed.coords)) {
        mid = routed.coords
        break
      }
    } catch (e) {
      if ((e as Error).name === 'AbortError') throw e
    }
  }

  if (!mid) {
    const via = await fetchFootViaSidewalkMids(snapFrom, snapTo, signal)
    if (via && !isChordLike(via.coords)) mid = via.coords
  }

  const snapGap = distanceMeters(
    snapFrom[0],
    snapFrom[1],
    snapTo[0],
    snapTo[1],
  )
  // Only allow a bare snap→snap mid when the gap is a tiny sidewalk stitch
  if (!mid && snapGap <= MAX_MID_CHORD_M) {
    mid = [snapFrom, snapTo]
  }

  const coords: [number, number][] = []

  // Short access connectors only (courtyard → sidewalk)
  if (distanceMeters(from[0], from[1], snapFrom[0], snapFrom[1]) <= MAX_STITCH_M) {
    pushUniqueCoord(coords, from)
  }
  pushUniqueCoord(coords, snapFrom)
  if (mid) {
    for (const p of mid) pushUniqueCoord(coords, p)
  }
  pushUniqueCoord(coords, snapTo)
  if (distanceMeters(to[0], to[1], snapTo[0], snapTo[1]) <= MAX_STITCH_M) {
    pushUniqueCoord(coords, to)
  }

  if (coords.length < 2) {
    // Absolute last resort: stay on snapped sidewalks only (no building chord)
    coords.length = 0
    if (snapGap <= MAX_MID_CHORD_M) {
      coords.push(snapFrom, snapTo)
    } else {
      // Cannot invent a path — pin both ends on the network without linking
      coords.push(snapFrom, snapFrom)
    }
  }

  const distM = pathLengthMeters(coords)
  return {
    coords,
    distanceMeters: Math.max(distM, 1),
    durationSeconds: walkDurationSeconds(Math.max(distM, 1)),
    isFallback: true,
    profile: 'foot',
  }
}

function isLongWalk(walk: RouteResult, straightM: number): boolean {
  if (walk.distanceMeters >= LONG_WALK_M) return true
  return (
    walk.distanceMeters > LONG_WALK_DETOUR_MIN_M &&
    straightM > 0 &&
    walk.distanceMeters / straightM > LONG_WALK_DETOUR_RATIO
  )
}

/**
 * Snap a point to the nearest walkable OSRM node on the foot instance.
 * Returns [lat, lng]. Falls back to the original point on failure.
 */
export async function snapToWalkNetwork(
  point: [number, number],
  signal?: AbortSignal,
): Promise<[number, number]> {
  const key = nearestKey(point)
  const hit = nearestCache.get(key)
  if (hit) return hit

  const [lat, lng] = point
  const path = apiUrl(
    `/api/route-foot/nearest/v1/foot/${lng},${lat}?number=1`,
  )
  const { signal: timed, clear } = withTimeoutSignal(signal)
  try {
    const res = await fetch(path, {
      signal: timed,
      headers: { Accept: 'application/json' },
    })
    if (!res.ok) return point
    const data = (await res.json()) as OsrmNearestResponse
    const loc = data.waypoints?.[0]?.location
    if (!loc || loc.length < 2) return point
    const snapped: [number, number] = [loc[1], loc[0]]
    nearestCache.set(key, snapped)
    return snapped
  } catch (e) {
    if ((e as Error).name === 'AbortError') throw e
    return point
  } finally {
    clear()
  }
}

async function fetchOsrmRoute(
  url: string,
  signal?: AbortSignal,
): Promise<RouteResult> {
  const { signal: timed, clear } = withTimeoutSignal(signal)
  try {
    let res: Response
    try {
      res = await fetch(url, {
        signal: timed,
        headers: { Accept: 'application/json' },
      })
    } catch (e) {
      if ((e as Error).name === 'AbortError') throw e
      throw new Error('Marsruuti ei õnnestunud leida (võrguviga)')
    }

    if (!res.ok) {
      throw new Error('Marsruuti ei õnnestunud leida')
    }

    let data: OsrmResponse
    try {
      data = (await res.json()) as OsrmResponse
    } catch {
      throw new Error('Marsruuti ei õnnestunud leida (tühi vastus)')
    }

    if (data.code !== 'Ok' || !data.routes?.[0]) {
      if (data.code === 'NoRoute') {
        throw new Error('Sihtkoht on liiga kaugel või teed ei leitud')
      }
      throw new Error('Marsruuti ei õnnestunud leida')
    }

    const route = data.routes[0]
    const lngLat = route.geometry?.coordinates
    if (!lngLat || lngLat.length < 2) {
      throw new Error('Marsruuti ei õnnestunud leida (tühi vastus)')
    }

    return {
      coords: lngLat.map(([lng, lat]) => [lat, lng] as [number, number]),
      distanceMeters: route.distance,
      durationSeconds: route.duration,
    }
  } finally {
    clear()
  }
}

/** Raw pedestrian route with endpoint radiuses (meters) for sidewalk snapping. */
async function fetchFootRouteRaw(
  from: [number, number],
  to: [number, number],
  signal?: AbortSignal,
  radiusM = 80,
  profile: (typeof FOOT_PROFILES)[number] = 'foot',
): Promise<RouteResult> {
  return fetchFootRouteMulti([from, to], signal, radiusM, profile)
}

/** Multi-waypoint pedestrian route on the OSM routed-foot instance. */
async function fetchFootRouteMulti(
  points: [number, number][],
  signal?: AbortSignal,
  radiusM = 80,
  profile: (typeof FOOT_PROFILES)[number] = 'foot',
): Promise<RouteResult> {
  if (points.length < 2) {
    throw new Error('Jalutusmarsruuti ei õnnestunud leida')
  }
  const coords = points.map(([lat, lng]) => `${lng},${lat}`).join(';')
  const radiuses = points.map(() => String(radiusM)).join(';')
  const qs = new URLSearchParams({
    overview: 'full',
    geometries: 'geojson',
    steps: 'false',
    alternatives: 'false',
    continue_straight: 'false',
    radiuses,
  })
  const url = apiUrl(`/api/route-foot/route/v1/${profile}/${coords}?${qs}`)
  const result = await fetchOsrmRoute(url, signal)
  return { ...result, profile: 'foot' }
}

/**
 * Pedestrian route via OSM routed-foot (sidewalks / footways / crossings).
 * Retries with larger radiuses and alternate pedestrian profiles; rejects
 * chord-like geometry that would cut through buildings.
 */
async function fetchWalkingRouteNetwork(
  from: [number, number],
  to: [number, number],
  signal?: AbortSignal,
): Promise<RouteResult> {
  let lastErr: Error | null = null
  for (const profile of FOOT_PROFILES) {
    for (const radius of WALK_RADII_M) {
      try {
        const routed = await fetchFootRouteRaw(
          from,
          to,
          signal,
          radius,
          profile,
        )
        if (isChordLike(routed.coords)) {
          lastErr = new Error('Jalutusmarsruut läbis ehitisi')
          continue
        }
        return routed
      } catch (e) {
        if ((e as Error).name === 'AbortError') throw e
        lastErr = e as Error
      }
    }
  }

  const via = await fetchFootViaSidewalkMids(from, to, signal)
  if (via && !isChordLike(via.coords)) return via

  throw lastErr ?? new Error('Jalutusmarsruuti ei õnnestunud leida')
}

/**
 * Fetch a single-leg route.
 * Driving prefers the OSM car instance, then project-osrm fallback.
 * Walking uses the OSM foot instance (pedestrian shortcuts).
 */
export async function fetchRoute(
  from: [number, number],
  to: [number, number],
  mode: RouteMode,
  signal?: AbortSignal,
): Promise<RouteResult> {
  const key = cacheKey(from, to, mode)
  const hit = routeCache.get(key)
  if (hit) return hit

  const [fromLat, fromLng] = from
  const [toLat, toLng] = to
  const coords = `${fromLng},${fromLat};${toLng},${toLat}`
  const qs = 'overview=full&geometries=geojson&steps=false&alternatives=false'

  let result: RouteResult

  if (mode === 'walking') {
    result = await fetchWalkingRouteNetwork(from, to, signal)
  } else {
    const primary = apiUrl(`/api/route-car/route/v1/driving/${coords}?${qs}`)
    const fallback = apiUrl(`/api/osrm/route/v1/driving/${coords}?${qs}`)
    try {
      result = await fetchOsrmRoute(primary, signal)
    } catch (e) {
      if ((e as Error).name === 'AbortError') throw e
      result = await fetchOsrmRoute(fallback, signal)
    }
    result = { ...result, profile: 'driving' }
  }

  routeCache.set(key, result)
  return result
}

/** @deprecated Prefer fetchRoute(..., 'driving') */
export async function fetchRouteProfile(
  from: [number, number],
  to: [number, number],
  profile: RouteProfile,
  signal?: AbortSignal,
): Promise<RouteResult> {
  const mode: RouteMode = profile === 'foot' ? 'walking' : 'driving'
  return fetchRoute(from, to, mode, signal)
}

/**
 * Optionally stitch marker endpoints onto the foot geometry with SHORT
 * sidewalk connectors only — never long chords through buildings.
 */
function stitchWalkEndpoints(
  walk: RouteResult,
  parking: [number, number],
  destination: [number, number],
): RouteResult {
  const coords = [...walk.coords]
  const first = coords[0]
  const last = coords[coords.length - 1]

  if (first) {
    const d = distanceMeters(first[0], first[1], parking[0], parking[1])
    if (d <= 0.5) {
      coords[0] = parking
    } else if (d <= MAX_STITCH_M) {
      coords.unshift(parking)
    }
    // else: leave at sidewalk — pin sits nearby without crossing blocks
  }

  if (last) {
    const end = coords[coords.length - 1]!
    const d = distanceMeters(end[0], end[1], destination[0], destination[1])
    if (d <= 0.5) {
      coords[coords.length - 1] = destination
    } else if (d <= MAX_STITCH_M) {
      coords.push(destination)
    }
  }

  return {
    ...walk,
    coords,
    distanceMeters: pathLengthMeters(coords),
    durationSeconds: walkDurationSeconds(pathLengthMeters(coords)),
  }
}

/** Tiny connector so the drive end meets the walk start when they diverge. */
function connectDriveToWalk(
  drive: RouteResult,
  walkStart: [number, number],
): RouteResult {
  const end = drive.coords[drive.coords.length - 1]
  if (!end) return drive
  const gap = distanceMeters(end[0], end[1], walkStart[0], walkStart[1])
  if (gap <= CONNECTOR_GAP_M) {
    // Snap the last drive vertex onto the walk start for a seamless join
    if (gap > 0.5) {
      return {
        ...drive,
        coords: [...drive.coords.slice(0, -1), walkStart],
      }
    }
    return drive
  }
  return {
    ...drive,
    coords: [...drive.coords, walkStart],
  }
}

/**
 * Build a full nav plan: drive user→parking + walk parking→destination.
 * Legs are requested in parallel. Walk failures yield a sidewalk-corridor
 * fallback (never a building-crossing straight line).
 */
export async function fetchRoutePlan(args: {
  from: [number, number]
  parking: [number, number]
  destination: [number, number] | null
  signal?: AbortSignal
}): Promise<RoutePlan> {
  const { from, parking, destination, signal } = args

  const needWalk =
    destination != null &&
    distanceMeters(parking[0], parking[1], destination[0], destination[1]) >=
      WALK_SKIP_M

  const drivePromise = fetchRoute(from, parking, 'driving', signal).then(
    (r) => ({ ok: true as const, value: r }),
    (e) => {
      if ((e as Error).name === 'AbortError') throw e
      return { ok: false as const, error: e as Error }
    },
  )

  const walkPromise: Promise<{
    ok: boolean
    value?: RouteResult
    failed?: boolean
  }> = (async () => {
    if (!needWalk || !destination) {
      return { ok: true, value: undefined }
    }
    try {
      const [snapPark, snapDest] = await Promise.all([
        snapToWalkNetwork(parking, signal),
        snapToWalkNetwork(destination, signal),
      ])
      const raw = await fetchRoute(snapPark, snapDest, 'walking', signal)
      if (isChordLike(raw.coords)) {
        throw new Error('Jalutusmarsruut läbis ehitisi')
      }
      const stitched = stitchWalkEndpoints(raw, parking, destination)
      return { ok: true, value: stitched, failed: false }
    } catch (e) {
      if ((e as Error).name === 'AbortError') throw e
      try {
        const corridor = await sidewalkCorridorFallback(
          parking,
          destination,
          signal,
        )
        return { ok: true, value: corridor, failed: true }
      } catch (e2) {
        if ((e2 as Error).name === 'AbortError') throw e2
        return { ok: true, value: undefined, failed: true }
      }
    }
  })()

  const [driveSettled, walkSettled] = await Promise.all([
    drivePromise,
    walkPromise,
  ])

  let drive: RouteResult | null = driveSettled.ok ? driveSettled.value : null
  const walk = walkSettled.value ?? null
  const walkFailed = Boolean(walkSettled.failed)

  if (drive && walk && walk.coords.length > 0) {
    drive = connectDriveToWalk(drive, walk.coords[0])
  }

  const straightM =
    destination != null
      ? distanceMeters(
          parking[0],
          parking[1],
          destination[0],
          destination[1],
        )
      : 0

  return {
    drive,
    walk,
    parking,
    destination,
    longWalk: walk && !walk.isFallback ? isLongWalk(walk, straightM) : false,
    walkFailed,
  }
}

/**
 * Walking route with sidewalk-aware fallback (for nearest-picker preview etc.).
 * Always prefers the OSM foot graph; short hops snap to the nearest sidewalk
 * instead of drawing a building-crossing chord.
 */
export async function fetchWalkingRoute(
  from: [number, number],
  to: [number, number],
  signal?: AbortSignal,
): Promise<RouteResult> {
  const dist = distanceMeters(from[0], from[1], to[0], to[1])
  if (dist < WALK_SKIP_M) {
    try {
      const [snapFrom, snapTo] = await Promise.all([
        snapToWalkNetwork(from, signal),
        snapToWalkNetwork(to, signal),
      ])
      const snapGap = distanceMeters(
        snapFrom[0],
        snapFrom[1],
        snapTo[0],
        snapTo[1],
      )
      // Same sidewalk node (or tiny gap): short access stitches only
      if (snapGap <= MAX_MID_CHORD_M) {
        const coords: [number, number][] = []
        if (
          distanceMeters(from[0], from[1], snapFrom[0], snapFrom[1]) <=
          MAX_STITCH_M
        ) {
          pushUniqueCoord(coords, from)
        }
        pushUniqueCoord(coords, snapFrom)
        pushUniqueCoord(coords, snapTo)
        if (
          distanceMeters(to[0], to[1], snapTo[0], snapTo[1]) <= MAX_STITCH_M
        ) {
          pushUniqueCoord(coords, to)
        }
        if (coords.length >= 2) {
          const distM = pathLengthMeters(coords)
          return {
            coords,
            distanceMeters: distM,
            durationSeconds: Math.max(30, Math.round(distM / 1.4)),
            profile: 'foot',
          }
        }
      }
      const raw = await fetchWalkingRouteNetwork(snapFrom, snapTo, signal)
      return stitchWalkEndpoints(raw, from, to)
    } catch (e) {
      if ((e as Error).name === 'AbortError') throw e
      // Truly tiny courtyard hop — allow a short stitch, never a long chord
      if (dist <= MAX_MID_CHORD_M) {
        return {
          coords: [from, to],
          distanceMeters: dist,
          durationSeconds: Math.max(30, Math.round(dist / 1.4)),
          isFallback: true,
          profile: 'foot',
        }
      }
      return sidewalkCorridorFallback(from, to, signal)
    }
  }
  try {
    const [snapFrom, snapTo] = await Promise.all([
      snapToWalkNetwork(from, signal),
      snapToWalkNetwork(to, signal),
    ])
    const raw = await fetchRoute(snapFrom, snapTo, 'walking', signal)
    if (isChordLike(raw.coords)) {
      return sidewalkCorridorFallback(from, to, signal)
    }
    return stitchWalkEndpoints(raw, from, to)
  } catch (e) {
    if ((e as Error).name === 'AbortError') throw e
    return sidewalkCorridorFallback(from, to, signal)
  }
}

/** Legacy wrapper — returns null on failure (older call sites). */
export async function fetchDrivingRoute(
  from: [number, number],
  to: [number, number],
): Promise<DrivingRoute | null> {
  try {
    const r = await fetchRoute(from, to, 'driving')
    const coordinates = routeCoordsToLngLat(r.coords)
    const [lng0, lat0] = coordinates[0]
    const look = coordinates[Math.min(8, coordinates.length - 1)]
    return {
      coordinates,
      callouts: [],
      distanceMeters: r.distanceMeters,
      durationSeconds: r.durationSeconds,
      bearing: bearingDegrees(lat0, lng0, look[1], look[0]),
    }
  } catch {
    return null
  }
}
