import {
  Box,
  Car,
  CircleHelp,
  Clock3,
  Footprints,
  Heart,
  Info,
  Loader2,
  LocateFixed,
  Map as MapIcon,
  Moon,
  Plus,
  Search,
  Shield,
  Sun,
  X,
} from 'lucide-react'
import { useCallback, useEffect, useMemo, useRef, useState, type KeyboardEvent } from 'react'
import { MapErrorBoundary } from './components/MapErrorBoundary'
import { MapView, type MapViewHandle } from './components/MapView'
import { ModalShell } from './components/ModalShell'
import { TeavePanel } from './components/TeavePanel'
import { PrivacyPanel } from './components/PrivacyPanel'
import { LocationInfoSheet } from './components/LocationInfoSheet'
import {
  NearestParkingPanel,
  parkingMapPillLabel,
  parkingMapPillTone,
  type NearestParkingOption,
} from './components/NearestParkingPanel'
import {
  collectNearestAround,
  NEAREST_DEFAULT_RADIUS_M,
  NEAREST_MAX_RADIUS_M,
  NEAREST_RADIUS_STEP_M,
} from './lib/nearestParking'
import { FavoritesPanel } from './components/FavoritesPanel'
import { ParkingDetailPanel } from './components/ParkingDetailPanel'
import type { CrowdStatusType } from './components/CrowdReportModal'
import { ParkingSessionModal } from './components/ParkingSessionModal'
import { OfflineBanner } from './components/OfflineBanner'
import { PwaBanners } from './components/PwaBanners'
import { ReportModal, type ReportModalContext } from './components/ReportModal'
import {
  SearchDropdown,
  splitPlaceLabel,
  suggestionOptionId,
  type SearchSuggestion,
} from './components/SearchDropdown'
import { MyPinSheet } from './components/MyPinSheet'
import { Toast } from './components/Toast'
import { MapChromeSkeleton } from './components/ui/Skeleton'
import {
  loadApprovedOverlays,
  loadSuppressedFeatureIds,
} from './lib/parkingRequests'
import { prefetchParkingLayers } from './lib/parkingDataCache'
import {
  CITIES,
  cityFromCoords,
  getInitialCity,
  isInsideEstoniaMapBounds,
  persistCity,
  type CityId,
} from './data/cities'
import { MOCK_KESKLINN_SPOTS } from './data/mockKesklinn'
import { PARKING_SPOTS } from './data/parking'
import { PARNU_ZONE_LIST } from './data/parnuZones'
import { ZONE_RATE_LIST } from './data/zones'
import {
  ALT_RADIUS_WIDE,
  findAlternatives,
  type AlternativeParking,
} from './lib/alternatives'
import { distanceMeters, formatDistance } from './lib/geo'
import {
  communityReportIds,
  formatCommunityReportLabel,
  postCommunityFullReport,
} from './lib/communityReports'
import { clearSpotFull, loadFullSpotIds, markSpotFull } from './lib/fullSpots'
import { submitFullReport } from './lib/submitFullReport'
import { useReports } from './hooks/useReports'
import { useTypeVotes } from './hooks/useTypeVotes'
import { applyVerifiedTypeToSpot } from './lib/typeVotes'
import {
  canSubmitReport,
  markReportSubmitted,
} from './lib/reportCooldown'
import {
  getParkingFilterCategory,
  isUnclassifiedParking,
  PARKING_COLOR_FREE,
  PARKING_COLOR_PAID,
  PARKING_COLOR_TIMED,
  PARKING_COLOR_UNKNOWN,
} from './lib/parkingClassification'
import { spotDisplayName } from './lib/parkingDisplayName'
import {
  fetchRoutePlan,
  fetchWalkingRoute,
  formatDuration,
  routeCoordsToLngLat,
  type NavRouteBundle,
} from './lib/routing'
import {
  geocodeToSearchLocation,
  type SearchLocation,
} from './lib/geocode'
import {
  addMyPin,
  loadHintSeen,
  loadMyPins,
  markHintSeen,
  markStorageUnavailableToastShown,
  MY_PINS_MAX,
  removeMyPin,
  updateMyPin,
  wasStorageUnavailableToastShown,
  type MyPin,
  type MyPinColor,
} from './lib/myPins'
import { normalizeSpot } from './lib/geojson'
import { useParkingSession } from './hooks/useParkingSession'
import { useSearchGeocode } from './hooks/useSearchGeocode'
import { clampSearchQuery } from './lib/validation'
import { track } from './lib/analytics'
import { useLiveLocation } from './hooks/useLiveLocation'
import { useI18n } from './i18n'

import { parkingIndex } from './lib/spatialIndex'
import { loadCustomSpots } from './lib/storage'
import {
  applyDocumentTheme,
  getInitialTheme,
  persistTheme,
  toggleTheme,
  type ThemeMode,
} from './lib/theme'
import { EV_COLOR_CYAN, type EvChargerFeature } from './lib/evChargers'
import { EvChargerSheet } from './components/EvChargerSheet'
import type { FilterId, ParkingSpot } from './types'

/** Top filter pills — labels via i18n inside App. */
const FILTER_META: { id: FilterId; labelKey: string; color?: string }[] = [
  { id: 'all', labelKey: 'filters.all' },
  { id: 'free_street', labelKey: 'filters.free', color: PARKING_COLOR_FREE },
  { id: 'timed', labelKey: 'filters.clock', color: PARKING_COLOR_TIMED },
  { id: 'paid', labelKey: 'filters.paid', color: PARKING_COLOR_PAID },
  { id: 'ev', labelKey: 'filters.ev', color: EV_COLOR_CYAN },
  { id: 'other', labelKey: 'filters.other', color: PARKING_COLOR_UNKNOWN },
  { id: 'alerts', labelKey: 'filters.alerts', color: '#FF3B30' },
]

/** Marker click does not auto-start a route (search selection does). */
const AUTO_ROUTE_ON_MARKER_CLICK = false

/** Solid ~95% panels — no backdrop-blur (keeps MapLibre at 60 FPS on mobile). */
const glass =
  'rounded-2xl border border-black/8 bg-white/95 shadow-[0_8px_28px_rgba(15,23,42,0.12)]'
const glassDark =
  'rounded-2xl border border-white/10 bg-[#1C1C1E]/95 shadow-[0_8px_28px_rgba(0,0,0,0.4)]'

export default function App() {
  const [theme, setTheme] = useState<ThemeMode>(() => getInitialTheme())
  const dark = theme === 'dark'
  const { t, formatMoney, zoneName } = useI18n()
  const FILTERS = useMemo(
    () =>
      FILTER_META.map((f) => ({
        id: f.id,
        label:
          f.id === 'alerts' ? `⚠️ ${t(f.labelKey)}` : t(f.labelKey),
        color: f.color,
      })),
    [t],
  )
  const [cityId, setCityId] = useState<CityId>(() => getInitialCity())
  const [filter, setFilter] = useState<FilterId>('all')
  const [query, setQuery] = useState('')
  const [isDropdownOpen, setIsDropdownOpen] = useState(false)
  const [activeIndex, setActiveIndex] = useState(0)
  const skipNextGeocode = useRef(false)
  const searchInputRef = useRef<HTMLInputElement | null>(null)
  const selectSearchSuggestionRef = useRef<(item: SearchSuggestion) => void>(
    () => {},
  )
  const [localFullSpotIds, setLocalFullSpotIds] = useState<Set<string>>(
    () => loadFullSpotIds(),
  )
  const {
    fullSpotIds: remoteFullIds,
    freeSpotIds: remoteFreeIds,
    getReport,
    refresh: refreshReports,
  } = useReports()
  const { byId: typeVoteById } = useTypeVotes()
  const fullSpotIds = useMemo(() => {
    const next = new Set<string>([...localFullSpotIds, ...remoteFullIds])
    return next
  }, [localFullSpotIds, remoteFullIds])
  const freeSpotIds = useMemo(() => {
    const next = new Set<string>()
    for (const id of remoteFreeIds) {
      if (!fullSpotIds.has(id)) next.add(id)
    }
    return next
  }, [remoteFreeIds, fullSpotIds])
  const [alternatives, setAlternatives] = useState<AlternativeParking[]>([])
  const [noAlternatives, setNoAlternatives] = useState(false)
  const {
    userLocation,
    hasGps,
    gpsLocating,
    followUser,
    stopFollow,
    locateAndFollow,
  } = useLiveLocation(CITIES[getInitialCity()].center)
  const [flyTarget, setFlyTarget] = useState<[number, number] | null>(null)
  const [flyZoom, setFlyZoom] = useState<number | undefined>(undefined)
  const [flyKey, setFlyKey] = useState(0)
  const [flyMode, setFlyMode] = useState<'fly' | 'ease'>('ease')
  const searchSheetTimer = useRef<number | null>(null)
  const [customSpots, setCustomSpots] = useState<ParkingSpot[]>([])
  const [selected, setSelected] = useState<ParkingSpot | null>(null)
  const [selectedEvCharger, setSelectedEvCharger] =
    useState<EvChargerFeature | null>(null)
  const [searchLocation, setSearchLocation] = useState<SearchLocation | null>(null)
  const [searchSheetOpen, setSearchSheetOpen] = useState(false)
  /** Step 1 after address search — pick among nearest parking options */
  const [nearestPickerOpen, setNearestPickerOpen] = useState(false)
  const [nearestOptions, setNearestOptions] = useState<NearestParkingOption[]>(
    [],
  )
  /** Search radius for “Lähimad parklad” chips (filter runs on this pool). */
  const [nearestRadiusM, setNearestRadiusM] = useState(NEAREST_DEFAULT_RADIUS_M)
  /** Tap/click preview in nearest picker — no hover (mobile has none). */
  const [selectedPreviewId, setSelectedPreviewId] = useState<string | null>(
    null,
  )
  /** Option keys visible under the active nearest-list filter (map pills sync). */
  const [nearestVisibleKeys, setNearestVisibleKeys] = useState<string[] | null>(
    null,
  )
  /** Detail was opened from nearest picker — show "Tagasi nimekirja". */
  const [fromNearestPicker, setFromNearestPicker] = useState(false)
  const [infoOpen, setInfoOpen] = useState(false)
  const [teaveOpen, setTeaveOpen] = useState(false)
  const [privacyOpen, setPrivacyOpen] = useState(false)
  const [favoritesOpen, setFavoritesOpen] = useState(false)
  const [reportContext, setReportContext] = useState<ReportModalContext | null>(null)
  const [approvedOverlays, setApprovedOverlays] = useState<ParkingSpot[]>([])
  const [suppressedIds, setSuppressedIds] = useState<Set<string>>(() => new Set())
  const [pitch3d, setPitch3d] = useState(true)
  const [preciseSpots, setPreciseSpots] = useState<ParkingSpot[]>([])
  const [streetSpots, setStreetSpots] = useState<ParkingSpot[]>([])
  const [mapReady, setMapReady] = useState(false)
  const [myPins, setMyPins] = useState<MyPin[]>(() => loadMyPins())
  const [draftPin, setDraftPin] = useState<{
    lat: number
    lng: number
    color: MyPinColor
  } | null>(null)
  const [editingPinId, setEditingPinId] = useState<string | null>(null)
  const [pinDragEnabled, setPinDragEnabled] = useState(false)
  const [myPinsExpanded, setMyPinsExpanded] = useState(false)
  const [draftColorPreview, setDraftColorPreview] = useState<MyPinColor>('red')
  const mapApiRef = useRef<MapViewHandle | null>(null)
  const routeAbort = useRef<AbortController | null>(null)
  const routeRunId = useRef(0)
  const gpsRouteToastShown = useRef(false)
  const [routePlan, setRoutePlan] = useState<NavRouteBundle | null>(null)
  const [routeSummaryReady, setRouteSummaryReady] = useState(false)
  const [, setRouteLoading] = useState(false)
  const [, setRouteError] = useState<string | null>(null)
  /** Pedestrian preview path [lng,lat][] for nearest-picker dashed link. */
  const [previewWalkPath, setPreviewWalkPath] = useState<
    [number, number][] | null
  >(null)
  const previewWalkAbort = useRef<AbortController | null>(null)

  const {
    geoResults,
    resultsQuery,
    geoLoading,
    geoError,
    pendingEnterSelect,
    cancelPendingEnter,
    armPendingEnter,
    clearGeo,
  } = useSearchGeocode({
    query,
    biasLat: userLocation[0],
    biasLng: userLocation[1],
    skipNextGeocodeRef: skipNextGeocode,
  })

  const {
    timerSeconds,
    timerMode,
    timerLabel,
    timerOpen,
    setTimerOpen,
    sessionLoading,
    sessionAction,
    activeSession,
    sessionNotice,
    priceEstimate,
    toast,
    setToast,
    dismissToast,
    connectionNotice,
    beginParkingSession,
    endParkingSession,
    refreshParkingStatus,
    addPrepaidMinutes,
    formatHourlyRate,
    formatSessionInstant,
  } = useParkingSession(selected)

  useEffect(() => {
    prefetchParkingLayers()
    setCustomSpots(loadCustomSpots())
    setApprovedOverlays(loadApprovedOverlays())
    setSuppressedIds(loadSuppressedFeatureIds())
    return () => {
      if (searchSheetTimer.current) window.clearTimeout(searchSheetTimer.current)
    }
  }, [])

  // Live GPS watch owned by useLiveLocation (clearWatch on unmount)

  // Nominatim geocoding owned by useSearchGeocode (debounce + pending Enter)

  // Prune expired local full-marks (remote polling owned by useReports)
  useEffect(() => {
    const prune = () => setLocalFullSpotIds(loadFullSpotIds())
    prune()
    const id = window.setInterval(prune, 60_000)
    return () => window.clearInterval(id)
  }, [])

  const clearRoute = useCallback(() => {
    routeRunId.current += 1
    routeAbort.current?.abort()
    routeAbort.current = null
    mapApiRef.current?.cancelRouteIntro()
    setRoutePlan(null)
    setRouteError(null)
    setRouteLoading(false)
    setRouteSummaryReady(false)
  }, [])

  /** Soft-switch parking layer when a destination falls in another city. */
  const ensureCityForCoords = useCallback(
    (lat: number, lng: number) => {
      const next = cityFromCoords(lat, lng)
      if (next === cityId) return
      setCityId(next)
      persistCity(next)
      setPreciseSpots([])
      setStreetSpots([])
    },
    [cityId],
  )

  const allSpots = useMemo(() => {
    const filteredPrecise = preciseSpots.filter((s) => !suppressedIds.has(s.id))
    const filteredStreet = streetSpots.filter((s) => !suppressedIds.has(s.id))

    if (cityId === 'parnu') {
      // Absolute ban: no on-street curb overlays — lots only
      const isStreetOverlay = (s: ParkingSpot) =>
        s.featureType === 'on-street-line' ||
        s.kind === 'street' ||
        Boolean(s.line)
      // Pärnu EV charger polygons/pins are not shown on the map
      const noEv = (s: ParkingSpot) => s.layer !== 'ev' && s.badge !== 'EV'
      const custom = customSpots
        .map((s) => normalizeSpot(s))
        .filter(
          (s) =>
            !suppressedIds.has(s.id) &&
            s.cityId !== 'tallinn' &&
            noEv(s) &&
            !isStreetOverlay(s),
        )
      const overlays = approvedOverlays
        .map((s) => normalizeSpot(s))
        .filter((s) => !suppressedIds.has(s.id) && noEv(s) && !isStreetOverlay(s))
      return [
        ...filteredPrecise.filter((s) => noEv(s) && !isStreetOverlay(s)),
        ...filteredStreet.filter((s) => noEv(s) && !isStreetOverlay(s)),
        ...custom,
        ...overlays,
      ]
    }

    const curated = PARKING_SPOTS.map((s) =>
      normalizeSpot({
        ...s,
        landmark: s.kind === 'lot' || s.type === 'pr' || s.id.startsWith('timed-'),
        layer:
          s.type === 'pr'
            ? 'park_ride'
            : s.type === 'timed'
              ? 'timed'
              : s.type === 'free' || s.zone_code === 'FREE'
                ? 'free_street'
                : 'municipal',
      }),
    )
    const mocks = MOCK_KESKLINN_SPOTS.map((s) => normalizeSpot(s))
    const custom = customSpots.map((s) => normalizeSpot(s))
    const overlays = approvedOverlays.map((s) => normalizeSpot(s))
    // Precise GeoJSON lots / street lines take precedence over stub mocks
    // Absolute ban: never include on-street curb / road-network features.
    // Map shows verified off-street lots (polygons + markers) only.
    const isStreetOverlay = (s: ParkingSpot) =>
      s.featureType === 'on-street-line' ||
      s.kind === 'street' ||
      Boolean(s.line)
    const mockWithoutDupes = mocks.filter((m) => {
      if (suppressedIds.has(m.id)) return false
      if (isStreetOverlay(m)) return false
      if (m.polygon) {
        return !preciseSpots.some(
          (p) =>
            p.layer === m.layer &&
            Math.abs(p.lat - m.lat) < 0.001 &&
            Math.abs(p.lng - m.lng) < 0.001,
        )
      }
      return true
    })
    return [
      ...filteredPrecise.filter((s) => !isStreetOverlay(s)),
      ...filteredStreet.filter((s) => !isStreetOverlay(s)),
      ...mockWithoutDupes,
      ...curated.filter((s) => !suppressedIds.has(s.id) && !isStreetOverlay(s)),
      ...custom.filter((s) => !isStreetOverlay(s)),
      ...overlays.filter((s) => !isStreetOverlay(s)),
    ]
  }, [
    cityId,
    customSpots,
    preciseSpots,
    streetSpots,
    approvedOverlays,
    suppressedIds,
  ])

  /** Apply community-verified types (2 matching votes) onto spots for filters/UI. */
  const typedSpots = useMemo(() => {
    if (typeVoteById.size === 0) return allSpots
    return allSpots.map((s) => {
      const v = typeVoteById.get(s.id)
      return v ? applyVerifiedTypeToSpot(s, v.verifiedType) : s
    })
  }, [allSpots, typeVoteById])

  const visibleSpots = useMemo(() => {
    if (filter === 'ev') {
      // Elektriautolaadijad — map uses dedicated EV GeoJSON; no parking pins
      return []
    }
    if (filter === 'alerts') {
      // Hoiatusega — only spots with active community isFull reports
      return typedSpots.filter((s) => fullSpotIds.has(s.id))
    }
    if (filter === 'free_street') {
      // Tasuta: exclusive unlimited-free bucket
      return typedSpots.filter((s) => getParkingFilterCategory(s) === 'free')
    }
    if (filter === 'timed') {
      // Kellaga: exclusive timed bucket (incl. Tallinn 15 min + paid after)
      return typedSpots.filter((s) => getParkingFilterCategory(s) === 'timed')
    }
    if (filter === 'paid') {
      // Tasuline — exclusive paid; never includes Kellaga/timed lots
      return typedSpots.filter(
        (s) => s.layer !== 'ev' && getParkingFilterCategory(s) === 'paid',
      )
    }
    if (filter === 'other') {
      return typedSpots.filter((s) =>
        isUnclassifiedParking({
          layer: s.layer,
          price_per_hour: s.price_per_hour,
          free_minutes: s.free_minutes,
          zone_code: s.zone_code,
          operator: s.operator,
          verified_free: s.layer === 'free_street',
          type: s.type,
          timeLimit: s.timeLimit,
          name: s.name,
          desc: s.desc,
          badge: s.badge,
        }),
      )
    }
    return typedSpots
  }, [typedSpots, filter, fullSpotIds])

  /** Detail panel / selection highlight use community-verified type when present. */
  const selectedDisplay = useMemo(() => {
    if (!selected) return null
    const v = typeVoteById.get(selected.id)
    return v ? applyVerifiedTypeToSpot(selected, v.verifiedType) : selected
  }, [selected, typeVoteById])

  /** Live search suggestions: my pins + parking + geocode (only fresh results). */
  const searchSuggestions = useMemo((): SearchSuggestion[] => {
    const qRaw = clampSearchQuery(query)
    const q = qRaw.toLowerCase()
    if (q.length < 3) return []

    const myPinHits: SearchSuggestion[] = myPins
      .filter((p) => p.name.toLowerCase().includes(q))
      .map((p) => ({
        kind: 'mypin' as const,
        id: p.id,
        name: p.name,
        subtitle: p.address || '',
        lat: p.lat,
        lng: p.lng,
        distanceM: distanceMeters(
          userLocation[0],
          userLocation[1],
          p.lat,
          p.lng,
        ),
        pin: p,
      }))
      .slice(0, 5)

    const parkingHits: SearchSuggestion[] = allSpots
      .filter((s) => {
        const name = spotDisplayName(s).toLowerCase()
        const zone = s.zone_code.toLowerCase()
        const addr = (s.address || '').toLowerCase()
        const op = (s.operator || '').toLowerCase()
        return (
          name.includes(q) ||
          zone.includes(q) ||
          addr.includes(q) ||
          op.includes(q) ||
          s.name.toLowerCase().includes(q)
        )
      })
      .map((s) => {
        const distanceM = distanceMeters(
          userLocation[0],
          userLocation[1],
          s.lat,
          s.lng,
        )
        return {
          kind: 'parking' as const,
          id: s.id,
          name: spotDisplayName(s),
          subtitle: [s.zone_code, s.operator, s.address]
            .filter(Boolean)
            .filter((v, i, a) => a.indexOf(v) === i)
            .slice(0, 2)
            .join(' · '),
          lat: s.lat,
          lng: s.lng,
          distanceM,
          spot: s,
        }
      })
      .sort((a, b) => a.distanceM - b.distanceM)
      .slice(0, 4)

    // Only attach Nominatim rows when they belong to the current query
    const places: SearchSuggestion[] =
      resultsQuery === qRaw
        ? geoResults
            .map((r) => {
              const { name, subtitle } = splitPlaceLabel(r.label)
              const distanceM = distanceMeters(
                userLocation[0],
                userLocation[1],
                r.lat,
                r.lng,
              )
              return {
                kind: 'place' as const,
                id: r.id,
                name: r.name || name,
                subtitle:
                  r.kind && r.kind !== 'place'
                    ? `${subtitle || r.kind}`
                    : subtitle,
                lat: r.lat,
                lng: r.lng,
                distanceM,
                result: r,
              }
            })
            .sort((a, b) => a.distanceM - b.distanceM)
        : []

    return [...myPinHits, ...parkingHits, ...places].slice(0, 12)
  }, [query, allSpots, geoResults, resultsQuery, userLocation, myPins])

  // Keep keyboard highlight on the top row when the list changes
  useEffect(() => {
    setActiveIndex(0)
  }, [searchSuggestions])

  /**
   * Pending Enter: when results for the armed query arrive, pick the top
   * suggestion automatically (same path as a click).
   */
  useEffect(() => {
    if (!pendingEnterSelect) return
    const q = clampSearchQuery(query)
    if (pendingEnterSelect !== q) return

    // Local hits (pins/parking) can resolve immediately without Nominatim
    if (searchSuggestions.length > 0) {
      const item = searchSuggestions[0]
      cancelPendingEnter()
      selectSearchSuggestionRef.current(item)
      return
    }

    // Still loading fresh geocode for this query
    if (geoLoading || resultsQuery !== q) return

    // Fresh empty / error result — clear pending, show empty/error UI
    cancelPendingEnter()
  }, [
    pendingEnterSelect,
    query,
    searchSuggestions,
    geoLoading,
    resultsQuery,
    cancelPendingEnter,
  ])

  // Deep-link: /?spot=<id> opens the parking sheet (no map click needed)
  const deepLinkApplied = useRef(false)
  useEffect(() => {
    if (deepLinkApplied.current || allSpots.length === 0) return
    const params = new URLSearchParams(window.location.search)
    const spotId = params.get('spot')?.trim()
    if (!spotId) return
    const match = allSpots.find((s) => s.id === spotId)
    if (!match) return
    deepLinkApplied.current = true
    setSelected(match)
    setFlyMode('fly')
    setFlyTarget([match.lat, match.lng])
    setFlyZoom(16)
    setFlyKey((k) => k + 1)
    // Drop ?spot= so a hard refresh lands on a clean map (not stuck on deep-link zoom)
    try {
      const url = new URL(window.location.href)
      url.searchParams.delete('spot')
      url.searchParams.delete('panel')
      url.searchParams.delete('timer')
      window.history.replaceState({}, '', url.pathname + url.search)
    } catch {
      /* ignore */
    }
    if (params.get('panel') === '1') {
      // Detail card owns the session form — do not also open the clock modal
      setTimerOpen(false)
    } else if (params.get('timer') === '1') {
      setSelected(null)
      setTimerOpen(true)
    }
  }, [allSpots, setTimerOpen])

  useEffect(() => {
    parkingIndex.bulkLoad(allSpots)
  }, [allSpots])

  const openSheet = useCallback(
    (spot: ParkingSpot) => {
      // Marker click: clear any prior search-route unless auto-route-on-click is enabled
      if (!AUTO_ROUTE_ON_MARKER_CLICK) {
        clearRoute()
      }
      // Exclusive with clock session modal — session lives inside this detail card
      setTimerOpen(false)
      setSearchSheetOpen(false)
      setNearestPickerOpen(false)
      setFromNearestPicker(false)
      setSelectedEvCharger(null)
      setSelected(spot)
      // Fly/zoom onto the lot — never leave the map at city/bay scale
      setFlyMode('fly')
      setFlyTarget([spot.lat, spot.lng])
      setFlyZoom(16)
      setFlyKey((k) => k + 1)
    },
    [clearRoute, setTimerOpen],
  )

  const openEvCharger = useCallback((feature: EvChargerFeature) => {
    clearRoute()
    setTimerOpen(false)
    setSearchSheetOpen(false)
    setNearestPickerOpen(false)
    setFromNearestPicker(false)
    setSelected(null)
    setSelectedEvCharger(feature)
  }, [clearRoute, setTimerOpen])

  const openSessionModal = useCallback(() => {
    // Exclusive with left detail panel — never stack both in the sidebar
    setSelected(null)
    setSelectedEvCharger(null)
    setNearestPickerOpen(false)
    setSearchSheetOpen(false)
    setTimerOpen(true)
  }, [setTimerOpen])

  const closeSessionModal = useCallback(() => {
    setTimerOpen(false)
  }, [setTimerOpen])

  const closeSheet = useCallback(() => setSelected(null), [])

  const dismissMapOverlays = useCallback(() => {
    clearRoute()
    setSelected(null)
    setSelectedEvCharger(null)
    setSearchSheetOpen(false)
    setNearestPickerOpen(false)
    setSelectedPreviewId(null)
    setFromNearestPicker(false)
    clearGeo()
    setIsDropdownOpen(false)
    setNoAlternatives(false)
    setDraftPin(null)
    setEditingPinId(null)
    setPinDragEnabled(false)
  }, [clearRoute, clearGeo])

  /** Cross-tab sync for personal pins (localStorage only). */
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === 'parking.myPins.v1') {
        setMyPins(loadMyPins())
      }
    }
    window.addEventListener('storage', onStorage)
    return () => window.removeEventListener('storage', onStorage)
  }, [])

  /** First-time long-press hint after map is ready. */
  useEffect(() => {
    if (!mapReady) return
    if (loadHintSeen()) return
    if (myPins.length > 0) {
      markHintSeen()
      return
    }
    const hintTimer = window.setTimeout(() => {
      setToast({
        kind: 'info',
        title: t('pins.longPressHint'),
      })
      markHintSeen()
    }, 1200)
    return () => window.clearTimeout(hintTimer)
  }, [mapReady, myPins.length, setToast, t])

  const notifyStorageIssue = useCallback(() => {
    if (wasStorageUnavailableToastShown()) return
    markStorageUnavailableToastShown()
    setToast({
      kind: 'info',
      title: t('pins.cannotSave'),
    })
  }, [setToast])

  const closePinSheet = useCallback(() => {
    setDraftPin(null)
    setEditingPinId(null)
    setPinDragEnabled(false)
  }, [])

  const handleLongPress = useCallback(
    (coords: { lat: number; lng: number }) => {
      setSelected(null)
      setSelectedEvCharger(null)
      setSearchSheetOpen(false)
      setNearestPickerOpen(false)
      setIsDropdownOpen(false)
      clearGeo()
      setEditingPinId(null)
      setDraftColorPreview('red')
      setDraftPin({ lat: coords.lat, lng: coords.lng, color: 'red' })
    },
    [clearGeo],
  )

  const handleMyPinClick = useCallback((pin: MyPin) => {
    setSelected(null)
    setSelectedEvCharger(null)
    setSearchSheetOpen(false)
    setNearestPickerOpen(false)
    setIsDropdownOpen(false)
    setDraftPin(null)
    setEditingPinId(pin.id)
  }, [])

  const handleCreatePin = useCallback(
    (payload: {
      name: string
      note: string
      color: MyPinColor
      lat: number
      lng: number
      address?: string
    }) => {
      const result = addMyPin({
        name: payload.name,
        note: payload.note,
        color: payload.color,
        lat: payload.lat,
        lng: payload.lng,
        address: payload.address,
      })
      if (!result.ok && result.reason === 'quota') {
        setToast({
          kind: 'info',
          title: t('pins.tooMany', { n: MY_PINS_MAX }),
        })
        return
      }
      setMyPins(result.pins)
      if (result.ok) {
        if (result.storageFailed) notifyStorageIssue()
        setToast({ kind: 'info', title: t('pins.saved') })
        markHintSeen()
      }
      setDraftPin(null)
      setEditingPinId(null)
    },
    [notifyStorageIssue, setToast],
  )

  const handleUpdatePin = useCallback(
    (
      id: string,
      payload: {
        name: string
        note: string
        color: MyPinColor
        lat: number
        lng: number
        address?: string
      },
    ) => {
      const result = updateMyPin(id, {
        name: payload.name,
        note: payload.note,
        color: payload.color,
        lat: payload.lat,
        lng: payload.lng,
        address: payload.address,
      })
      setMyPins(result.pins)
      if (result.ok) {
        setToast({ kind: 'info', title: t('pins.saved') })
      }
      setEditingPinId(null)
      setPinDragEnabled(false)
    },
    [setToast],
  )

  const handleDeletePin = useCallback(
    (id: string) => {
      const { pins } = removeMyPin(id)
      setMyPins(pins)
      setEditingPinId(null)
      setPinDragEnabled(false)
      setToast({ kind: 'info', title: t('pins.deleted') })
    },
    [setToast],
  )

  const handleMyPinDragEnd = useCallback(
    (pinId: string, coords: { lat: number; lng: number }) => {
      const result = updateMyPin(pinId, {
        lat: coords.lat,
        lng: coords.lng,
        address: '', // clear stale reverse-geocode; sheet will refetch
      })
      setMyPins(result.pins)
    },
    [],
  )

  const clearSearchLocation = useCallback(() => {
    clearRoute()
    setSearchLocation(null)
    setSearchSheetOpen(false)
    setNearestPickerOpen(false)
    setNearestOptions([])
    setSelectedPreviewId(null)
    setFromNearestPicker(false)
    setQuery('')
    clearGeo()
    setIsDropdownOpen(false)
    setAlternatives([])
    setNoAlternatives(false)
  }, [clearRoute, clearGeo])

  const visibleIdSet = useMemo(
    () => new Set(visibleSpots.map((s) => s.id)),
    [visibleSpots],
  )

  const openSearchSheet = useCallback(() => {
    if (!searchLocation) return
    setSelected(null)
    setSearchSheetOpen(true)
  }, [searchLocation])

  /** FAB "Jälgi mind" — fresh GPS fix, enable auto-follow, snap camera. */
  const locateMe = useCallback(async () => {
    if (gpsLocating) return
    const result = await locateAndFollow()
    if (!result.ok) {
      setToast({
        kind: 'error',
        title: t('chrome.locationMissing'),
        detail: result.message,
      })
      return
    }
    const { lat, lng } = result.position
    if (!isInsideEstoniaMapBounds(lat, lng)) {
      stopFollow()
      setToast({
        kind: 'info',
        title: t('chrome.outsideEstonia'),
      })
      return
    }
    setFlyMode('fly')
    setFlyTarget([lat, lng])
    setFlyZoom(16)
    setFlyKey((k) => k + 1)
  }, [gpsLocating, locateAndFollow, setToast, stopFollow])

  /** All roadside/lot spots within radius — panel filters, then limits display. */
  const collectNearestOptions = useCallback(
    (lat: number, lng: number, radiusM = nearestRadiusM): NearestParkingOption[] => {
      return collectNearestAround(allSpots, lat, lng, {
        excludeIds: fullSpotIds,
        radiusM,
      })
    },
    [allSpots, fullSpotIds, nearestRadiusM],
  )

  /**
   * Step 2 — user confirmed a parking card: open detail panel + route intro
   * (drive to lot, walk to house).
   */
  const confirmParkingSelection = useCallback(
    (houseLoc: SearchLocation, destSpot: ParkingSpot | null) => {
      if (searchSheetTimer.current) {
        window.clearTimeout(searchSheetTimer.current)
        searchSheetTimer.current = null
      }

      const runId = routeRunId.current + 1
      routeRunId.current = runId
      routeAbort.current?.abort()
      mapApiRef.current?.cancelRouteIntro()
      setRoutePlan(null)
      setRouteError(null)
      setRouteLoading(false)
      setRouteSummaryReady(false)
      setNearestPickerOpen(false)
      setSelectedPreviewId(null)
      setSearchSheetOpen(false)
      setAlternatives([])
      setNoAlternatives(false)
      setTimerOpen(false)

      const house: [number, number] = [houseLoc.lat, houseLoc.lng]
      const parking: [number, number] = destSpot
        ? [destSpot.lat, destSpot.lng]
        : house
      const sameAsHouse =
        !destSpot ||
        (Math.abs(parking[0] - house[0]) < 1e-6 &&
          Math.abs(parking[1] - house[1]) < 1e-6)
      const label =
        destSpot?.name || houseLoc.name || houseLoc.label || t('common.destination')

      const openInfoSheet = () => {
        if (routeRunId.current !== runId) return
        if (destSpot) {
          setTimerOpen(false)
          setSearchSheetOpen(false)
          setSelected(destSpot)
        } else {
          setSelected(null)
          setSearchSheetOpen(true)
        }
      }

      // Immediately frame the chosen lot (detail zoom) — route intro may refine later
      if (destSpot) {
        setFlyMode('fly')
        setFlyTarget([destSpot.lat, destSpot.lng])
        setFlyZoom(16)
        setFlyKey((k) => k + 1)
      }

      const nearUser =
        distanceMeters(
          userLocation[0],
          userLocation[1],
          parking[0],
          parking[1],
        ) < 40

      if (nearUser) {
        if (!destSpot) {
          setFlyMode('fly')
          setFlyTarget(house)
          setFlyZoom(17)
          setFlyKey((k) => k + 1)
        }
        searchSheetTimer.current = window.setTimeout(() => {
          openInfoSheet()
          searchSheetTimer.current = null
        }, 900)
        return
      }

      if (!hasGps && !gpsRouteToastShown.current) {
        gpsRouteToastShown.current = true
        setToast({
          kind: 'info',
          title: t('geo.gpsMissing'),
          detail:
            t('geo.gpsMissingRoute'),
        })
      }

      const ac = new AbortController()
      routeAbort.current = ac
      setRouteLoading(true)
      setRouteError(null)
      const timeout = window.setTimeout(() => ac.abort(), 8000)

      let resolvedPlan: Awaited<ReturnType<typeof fetchRoutePlan>> | null = null
      const planPromise = fetchRoutePlan({
        from: userLocation,
        parking,
        destination: sameAsHouse ? null : house,
        signal: ac.signal,
      })
        .then((plan) => {
          if (ac.signal.aborted || routeRunId.current !== runId) return null
          resolvedPlan = plan
          return plan
        })
        .catch((e) => {
          if ((e as Error).name === 'AbortError') return null
          if (routeRunId.current === runId) {
            const msg =
              e instanceof Error ? e.message : 'Marsruuti ei õnnestunud leida'
            setRouteError(msg)
            setToast({
              kind: 'info',
              title: t('toasts.routeFail'),
            })
          }
          return null
        })
        .finally(() => {
          window.clearTimeout(timeout)
          if (routeAbort.current === ac) {
            setRouteLoading(false)
            routeAbort.current = null
          }
        })

      const waitForRoute = planPromise.then((p) => p?.drive ?? null)
      const waitForWalkRoute = planPromise.then((p) => {
        if (p?.walkFailed && routeRunId.current === runId) {
          setToast({
            kind: 'info',
            title: t('toasts.walkRouteMissing'),
            detail: t('toasts.walkRouteFallback'),
          })
        }
        return p?.walk ?? null
      })

      void mapApiRef.current
        ?.playRouteIntro({
          house,
          parking,
          origin: userLocation,
          waitForRoute,
          waitForWalkRoute,
          routeWaitMs: 3000,
          onBeforeFitBounds: (drive, walk) => {
            if (routeRunId.current !== runId) return
            if (!drive && walk) {
              setToast({
                kind: 'info',
                title: t('toasts.driveRouteMissing'),
                detail: t('toasts.driveWalkOnly'),
              })
            }
            setRoutePlan({
              drive,
              walk,
              parking,
              destination: sameAsHouse ? null : house,
              house,
              label,
              longWalk: resolvedPlan?.longWalk ?? false,
              walkFailed: resolvedPlan?.walkFailed ?? Boolean(walk?.isFallback),
            })
            openInfoSheet()
          },
          onFailed: () => {
            if (routeRunId.current !== runId) return
            setToast({
              kind: 'info',
              title: t('toasts.routeFail'),
            })
            openInfoSheet()
          },
        })
        .then((status) => {
          if (routeRunId.current !== runId) return
          if (status === 'fitted') setRouteSummaryReady(true)
        })
    },
    [hasGps, userLocation, setToast],
  )

  /**
   * Step 1 — address/place search: show Nearest Parking Options panel.
   * Parking suggestions from the dropdown skip the picker and confirm directly.
   */
  const flyToDestination = (
    loc: SearchLocation,
    opts?: { preferSpot?: ParkingSpot | null; skipPicker?: boolean },
  ) => {
    if (searchSheetTimer.current) {
      window.clearTimeout(searchSheetTimer.current)
      searchSheetTimer.current = null
    }

    routeAbort.current?.abort()
    mapApiRef.current?.cancelRouteIntro()
    setRoutePlan(null)
    setRouteError(null)
    setRouteLoading(false)
    setRouteSummaryReady(false)

    ensureCityForCoords(loc.lat, loc.lng)

    skipNextGeocode.current = true
    clearGeo()
    setIsDropdownOpen(false)
    searchInputRef.current?.blur()

    setSearchSheetOpen(false)
    setSelected(null)
    setSearchLocation(loc)
    setQuery(loc.name)
    setAlternatives([])
    setNoAlternatives(false)
    setSelectedPreviewId(null)

    // Direct confirm when user picked a parking result from search
    if (opts?.preferSpot || opts?.skipPicker) {
      setFromNearestPicker(false)
      confirmParkingSelection(loc, opts.preferSpot ?? null)
      return
    }

    const radiusM = NEAREST_DEFAULT_RADIUS_M
    setNearestRadiusM(radiusM)
    const options = collectNearestOptions(loc.lat, loc.lng, radiusM)
    setNearestOptions(options)
    setFromNearestPicker(false)
    setNearestPickerOpen(true)
    setSelectedPreviewId(options[0]?.optionKey ?? null)

    // Do NOT fly to destination alone — MapView previewFocus.fitBounds
    // frames destination + all nearby lots (avoids city/bay scale + race).
    setFlyTarget(null)

    if (options.length === 0) {
      // No parking nearby — fall back to location info sheet + fly to dest
      setNearestPickerOpen(false)
      setSearchSheetOpen(true)
      setFlyMode('fly')
      setFlyTarget([loc.lat, loc.lng])
      setFlyZoom(16)
      setFlyKey((k) => k + 1)
    }
  }

  const selectSearchSuggestion = (item: SearchSuggestion) => {
    cancelPendingEnter()
    if (item.kind === 'mypin') {
      skipNextGeocode.current = true
      clearGeo()
      setIsDropdownOpen(false)
      searchInputRef.current?.blur()
      setQuery(item.pin.name)
      setFlyMode('fly')
      setFlyTarget([item.pin.lat, item.pin.lng])
      setFlyZoom(16.5)
      setFlyKey((k) => k + 1)
      handleMyPinClick(item.pin)
      return
    }
    if (item.kind === 'parking') {
      flyToDestination(
        {
          id: item.spot.id,
          name: spotDisplayName(item.spot),
          label: item.spot.address || spotDisplayName(item.spot),
          lat: item.spot.lat,
          lng: item.spot.lng,
          kind: 'parking',
        },
        { preferSpot: item.spot, skipPicker: true },
      )
      return
    }
    flyToDestination(geocodeToSearchLocation(item.result))
  }
  selectSearchSuggestionRef.current = selectSearchSuggestion

  const handleSearchKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    const composing =
      e.nativeEvent.isComposing ||
      (e as unknown as { keyCode?: number }).keyCode === 229
    const q = clampSearchQuery(query)
    const suggestions = q.length >= 3 ? searchSuggestions : []
    const listOpen = isDropdownOpen && (q.length >= 3 || myPins.length > 0)

    if (e.key === 'Escape') {
      e.preventDefault()
      cancelPendingEnter()
      setIsDropdownOpen(false)
      searchInputRef.current?.blur()
      return
    }

    if (e.key === 'Tab') {
      cancelPendingEnter()
      setIsDropdownOpen(false)
      return
    }

    if (e.key === 'ArrowDown' && listOpen && suggestions.length > 0) {
      e.preventDefault()
      setActiveIndex((i) => (i + 1) % suggestions.length)
      return
    }

    if (e.key === 'ArrowUp' && listOpen && suggestions.length > 0) {
      e.preventDefault()
      setActiveIndex(
        (i) => (i - 1 + suggestions.length) % suggestions.length,
      )
      return
    }

    if (e.key !== 'Enter') return
    if (composing) return
    if (q.length < 3) return
    e.preventDefault()

    // After a selection the dropdown stays closed — second Enter is a no-op
    if (!isDropdownOpen && !pendingEnterSelect) return

    setIsDropdownOpen(true)

    // Combined list only includes fresh Nominatim rows (resultsQuery match),
    // so any non-empty list is safe to pick from immediately.
    if (suggestions.length > 0) {
      const idx = Math.min(
        Math.max(activeIndex, 0),
        suggestions.length - 1,
      )
      selectSearchSuggestion(suggestions[idx])
      return
    }

    // Still loading / stale / empty pending → skip debounce and wait
    armPendingEnter(q)
  }

  const navigateToMyPin = (pin: MyPin) => {
    closePinSheet()
    flyToDestination({
      id: `mypin-${pin.id}`,
      name: pin.name,
      label: pin.address || pin.name,
      lat: pin.lat,
      lng: pin.lng,
      kind: 'mypin',
    })
  }

  /** Instant preview only — no detail panel. Strict single selection. */
  const handleNearestPreview = useCallback((id: string) => {
    setSelectedPreviewId(id)
  }, [])

  /** Explicit "Vali see parkla" — opens detail + starts route. */
  const handleNearestConfirm = useCallback(
    (spot: ParkingSpot) => {
      if (!searchLocation) return
      setFromNearestPicker(true)
      confirmParkingSelection(searchLocation, spot)
    },
    [searchLocation, confirmParkingSelection],
  )

  const handleBackToNearestList = useCallback(() => {
    clearRoute()
    setSelected(null)
    setRouteSummaryReady(false)
    setFromNearestPicker(true)
    setNearestPickerOpen(true)
    if (nearestOptions[0]) {
      setSelectedPreviewId(nearestOptions[0].optionKey)
    }
  }, [clearRoute, nearestOptions])

  // Refresh nearest list when parking data / radius changes after a search.
  // Always anchor distances to searchLocation — never keep stale Tallinn rows
  // after navigating to Tartu / another landmark.
  useEffect(() => {
    if (!nearestPickerOpen || !searchLocation) return
    const next = collectNearestOptions(
      searchLocation.lat,
      searchLocation.lng,
      nearestRadiusM,
    )
    setNearestOptions(next)
    setSelectedPreviewId((prev) => {
      if (prev && next.some((o) => o.optionKey === prev)) return prev
      return next[0]?.optionKey ?? null
    })
  }, [
    allSpots,
    nearestPickerOpen,
    searchLocation,
    nearestRadiusM,
    collectNearestOptions,
  ])

  const handleNearestWidenRadius = useCallback(() => {
    setNearestRadiusM((r) =>
      Math.min(r + NEAREST_RADIUS_STEP_M, NEAREST_MAX_RADIUS_M),
    )
  }, [])

  // Prefocus the closest option when the picker opens
  useEffect(() => {
    if (!nearestPickerOpen) return
    if (selectedPreviewId) return
    if (nearestOptions[0]) setSelectedPreviewId(nearestOptions[0].optionKey)
  }, [nearestPickerOpen, nearestOptions, selectedPreviewId])

  // Pedestrian OSRM path for nearest-picker dashed preview (parking → house)
  useEffect(() => {
    if (!nearestPickerOpen || !searchLocation || !selectedPreviewId) {
      previewWalkAbort.current?.abort()
      previewWalkAbort.current = null
      setPreviewWalkPath(null)
      return
    }
    const hit = nearestOptions.find((o) => o.optionKey === selectedPreviewId)
    if (!hit) {
      setPreviewWalkPath(null)
      return
    }

    const ctrl = new AbortController()
    previewWalkAbort.current?.abort()
    previewWalkAbort.current = ctrl
    setPreviewWalkPath(null)

    const from: [number, number] = [hit.spot.lat, hit.spot.lng]
    const to: [number, number] = [searchLocation.lat, searchLocation.lng]

    fetchWalkingRoute(from, to, ctrl.signal)
      .then((route) => {
        if (ctrl.signal.aborted) return
        setPreviewWalkPath(routeCoordsToLngLat(route.coords))
      })
      .catch((e) => {
        if ((e as Error).name === 'AbortError') return
        // fetchWalkingRoute already sidewalk-snaps; leave empty rather than chord
        setPreviewWalkPath(null)
      })

    return () => {
      ctrl.abort()
    }
  }, [
    nearestPickerOpen,
    searchLocation,
    selectedPreviewId,
    nearestOptions,
  ])

  const nearestPills = useMemo(() => {
    if (!nearestPickerOpen) return []
    const visible = nearestVisibleKeys
      ? nearestOptions.filter((o) => nearestVisibleKeys.includes(o.optionKey))
      : nearestOptions
    return visible.map(({ spot, optionKey }) => ({
      id: optionKey,
      lat: spot.lat,
      lng: spot.lng,
      label: parkingMapPillLabel(spot),
      tone: parkingMapPillTone(spot),
    }))
  }, [nearestPickerOpen, nearestOptions, nearestVisibleKeys])

  const previewFocus = useMemo(() => {
    if (!nearestPickerOpen || !searchLocation) return null
    const hit = selectedPreviewId
      ? nearestOptions.find((o) => o.optionKey === selectedPreviewId)
      : null
    return {
      target: { lat: searchLocation.lat, lng: searchLocation.lng },
      parking: hit
        ? { lat: hit.spot.lat, lng: hit.spot.lng }
        : undefined,
      // Fit cluster once — do not re-camera on every preview tap (keeps taps instant)
      fitAll: true,
      walkPath: previewWalkPath,
    }
  }, [
    nearestPickerOpen,
    searchLocation,
    selectedPreviewId,
    nearestOptions,
    previewWalkPath,
  ])

  /** Route camera + OSRM intro to a parking spot (alternatives flow). */
  const routeToSpot = useCallback(
    (spot: ParkingSpot, opts?: { toastTitle?: string }) => {
      const runId = routeRunId.current + 1
      routeRunId.current = runId
      routeAbort.current?.abort()
      mapApiRef.current?.cancelRouteIntro()
      setRoutePlan(null)
      setRouteError(null)
      setRouteLoading(false)
      setRouteSummaryReady(false)
      setSearchSheetOpen(false)
      setSelected(spot)
      setIsDropdownOpen(false)

      const parking: [number, number] = [spot.lat, spot.lng]
      // Keep original house destination when available
      const house: [number, number] = searchLocation
        ? [searchLocation.lat, searchLocation.lng]
        : parking
      const sameAsHouse =
        Math.abs(parking[0] - house[0]) < 1e-6 &&
        Math.abs(parking[1] - house[1]) < 1e-6
      const label = spotDisplayName(spot)

      if (opts?.toastTitle) {
        setToast({ kind: 'info', title: opts.toastTitle })
      }

      const nearUser =
        distanceMeters(
          userLocation[0],
          userLocation[1],
          parking[0],
          parking[1],
        ) < 40

      if (nearUser) {
        setFlyMode('fly')
        setFlyTarget(house)
        setFlyZoom(17)
        setFlyKey((k) => k + 1)
        return
      }

      const ac = new AbortController()
      routeAbort.current = ac
      setRouteLoading(true)
      const timeout = window.setTimeout(() => ac.abort(), 8000)

      let resolvedPlan: Awaited<ReturnType<typeof fetchRoutePlan>> | null = null
      const planPromise = fetchRoutePlan({
        from: userLocation,
        parking,
        destination: sameAsHouse ? null : house,
        signal: ac.signal,
      })
        .then((plan) => {
          if (ac.signal.aborted || routeRunId.current !== runId) return null
          resolvedPlan = plan
          return plan
        })
        .catch((e) => {
          if ((e as Error).name === 'AbortError') return null
          if (routeRunId.current === runId) {
            setToast({
              kind: 'info',
              title: t('toasts.routeFail'),
            })
          }
          return null
        })
        .finally(() => {
          window.clearTimeout(timeout)
          if (routeAbort.current === ac) {
            setRouteLoading(false)
            routeAbort.current = null
          }
        })

      const waitForRoute = planPromise.then((p) => p?.drive ?? null)
      const waitForWalkRoute = planPromise.then((p) => {
        if (p?.walkFailed && routeRunId.current === runId) {
          setToast({
            kind: 'info',
            title: t('toasts.walkRouteMissing'),
            detail: t('toasts.walkRouteFallback'),
          })
        }
        return p?.walk ?? null
      })

      void mapApiRef.current
        ?.playRouteIntro({
          house,
          parking,
          origin: userLocation,
          waitForRoute,
          waitForWalkRoute,
          routeWaitMs: 3000,
          onBeforeFitBounds: (drive, walk) => {
            if (routeRunId.current !== runId) return
            setRoutePlan({
              drive,
              walk,
              parking,
              destination: sameAsHouse ? null : house,
              house,
              label,
              longWalk: resolvedPlan?.longWalk ?? false,
              walkFailed: resolvedPlan?.walkFailed ?? Boolean(walk?.isFallback),
            })
          },
          onFailed: () => {
            if (routeRunId.current !== runId) return
            setFlyMode('fly')
            setFlyTarget(house)
            setFlyZoom(16.5)
            setFlyKey((k) => k + 1)
          },
        })
        .then((status) => {
          if (routeRunId.current !== runId) return
          if (status === 'fitted') setRouteSummaryReady(true)
        })
    },
    [userLocation, searchLocation, setToast],
  )

  const runFindAlternatives = useCallback(
    (opts?: {
      markFullId?: string
      maxRadius?: number
      autoGo?: boolean
    }) => {
      const origin = searchLocation
        ? { lat: searchLocation.lat, lng: searchLocation.lng }
        : selected
          ? { lat: selected.lat, lng: selected.lng }
          : null
      if (!origin) return

      let nextFull = fullSpotIds
      if (opts?.markFullId) {
        if (!canSubmitReport(opts.markFullId)) return
        nextFull = markSpotFull(opts.markFullId)
        setLocalFullSpotIds(nextFull)
        markReportSubmitted(opts.markFullId)
        const marked =
          allSpots.find((s) => s.id === opts.markFullId) ?? selected
        void postCommunityFullReport({
          spotId: opts.markFullId,
          lat: marked?.lat,
          lng: marked?.lng,
          isFull: true,
        }).then((reports) => {
          if (reports.length > 0) void refreshReports()
          else {
            const remote = communityReportIds(reports)
            setLocalFullSpotIds(
              new Set([...loadFullSpotIds(), ...remote]),
            )
          }
        })
      }

      const exclude = new Set<string>([...nextFull])
      if (selected) exclude.add(selected.id)
      if (opts?.markFullId) exclude.add(opts.markFullId)

      const { results } = findAlternatives({
        origin,
        candidates: allSpots,
        excludeIds: exclude,
        fullIds: nextFull,
        matchesFilter: (s) => visibleIdSet.has(s.id),
        maxRadius: opts?.maxRadius,
        limit: 6,
      })

      setAlternatives(results)
      setNoAlternatives(results.length === 0)

      if (results.length > 0 && opts?.autoGo !== false) {
        routeToSpot(results[0].spot, {
          toastTitle: 'Leidsime lähima vaba parkla',
        })
      }
    },
    [
      searchLocation,
      selected,
      fullSpotIds,
      allSpots,
      visibleIdSet,
      routeToSpot,
      refreshReports,
    ],
  )

  const handleFindAnother = useCallback(() => {
    runFindAlternatives({ autoGo: true })
  }, [runFindAlternatives])

  const handleMarkFull = useCallback(() => {
    if (!selected) return
    const parkingId = selected.id
    const spotLat = selected.lat
    const spotLng = selected.lng
    if (!canSubmitReport(parkingId)) {
      setToast({
        kind: 'info',
        title: 'Sama parkla jaoks oota 5 minutit',
      })
      return
    }
    setToast({ kind: 'loading', title: t('toasts.sending') })
    void (async () => {
      const result = await submitFullReport(parkingId, {
        lat: spotLat,
        lng: spotLng,
      })
      if (!result.ok) {
        setToast({
          kind: result.cooldown ? 'info' : 'error',
          title: result.message,
        })
        return
      }
      setLocalFullSpotIds(markSpotFull(parkingId))
      void refreshReports()
      setToast({
        kind: 'success',
        title: 'Raport saadetud',
        actionLabel: 'Võta tagasi',
        onAction: () => {
          setLocalFullSpotIds(clearSpotFull(parkingId))
        },
      })
      runFindAlternatives({ autoGo: true })
    })()
  }, [selected, runFindAlternatives, setToast, refreshReports])

  const handleCrowdReportSuccess = useCallback(
    (payload: {
      statusType: CrowdStatusType
      comment: string
      message: string
    }) => {
      setToast({
        kind: 'success',
        title: payload.message,
      })
      if (selected) {
        markReportSubmitted(selected.id)
        void refreshReports()
      }
      if (
        selected &&
        payload.statusType === 'full'
      ) {
        // API already stored the report — only sync local TTL + suggest alternatives
        setLocalFullSpotIds(markSpotFull(selected.id))
        runFindAlternatives({ autoGo: true })
      }
    },
    [selected, runFindAlternatives, setToast, refreshReports],
  )

  const handleWidenRadius = useCallback(() => {
    runFindAlternatives({ maxRadius: ALT_RADIUS_WIDE, autoGo: true })
  }, [runFindAlternatives])

  const handleSelectAlternative = useCallback(
    (spot: ParkingSpot) => {
      routeToSpot(spot, { toastTitle: 'Leidsime lähima vaba parkla' })
    },
    [routeToSpot],
  )

  const openProposeNew = () => {
    setReportContext({
      mode: 'PROPOSE_NEW',
      lat: userLocation[0],
      lng: userLocation[1],
      target: selected,
    })
  }

  const openReportInvalid = (spot: ParkingSpot) => {
    setReportContext({
      mode: 'REPORT_INVALID',
      lat: spot.lat,
      lng: spot.lng,
      target: spot,
    })
  }

  useEffect(() => {
    applyDocumentTheme(theme)
  }, [theme])

  const panel = dark ? glassDark : glass
  const muted = dark ? 'text-[#98989D]' : 'text-[#8E8E93]'
  const text = dark ? 'text-[#F5F5F7]' : 'text-[#1C1C1E]'
  const chip = dark
    ? 'bg-white/10 text-[#EBEBF5] hover:bg-white/16'
    : 'bg-white/70 text-[#3A3A3C] hover:bg-white'
  const chipActive = dark ? 'bg-white text-[#1C1C1E]' : 'bg-[#1C1C1E] text-white'

  const selectedDist = selected
    ? formatDistance(
        distanceMeters(userLocation[0], userLocation[1], selected.lat, selected.lng),
      )
    : null

  const fabClass = `tap-scale flex h-[52px] w-[52px] items-center justify-center rounded-full ${panel} ${text} shadow-[0_4px_16px_rgba(15,23,42,0.14)]`

  /** Detail / sheet open — hide map chrome clutter on mobile. */
  const detailChromeOpen = Boolean(
    selected ||
      selectedEvCharger ||
      (searchSheetOpen && searchLocation) ||
      nearestPickerOpen ||
      draftPin ||
      editingPinId ||
      favoritesOpen,
  )

  return (
    <div className={`relative h-full overflow-hidden ${dark ? 'bg-[#0f1714]' : 'bg-transparent'}`}>
      {/* Full-bleed map — z-0 base layer */}
      <div className="absolute inset-0 z-0">
        <MapErrorBoundary>
          <MapView
            ref={mapApiRef}
            spots={visibleSpots}
            filter={filter}
            theme={theme}
            userLocation={userLocation}
            followUser={followUser}
            onUserMapGesture={stopFollow}
            flyTarget={flyTarget}
            flyKey={flyKey}
            flyZoom={flyZoom}
            flyMode={flyMode}
            pitch3d={pitch3d}
            selectedId={selected?.id ?? null}
            highlightId={
              nearestPickerOpen
                ? nearestOptions.find((o) => o.optionKey === selectedPreviewId)
                    ?.spot.id ?? null
                : null
            }
            nearestActivePillId={
              nearestPickerOpen ? selectedPreviewId : null
            }
            nearestPills={nearestPills}
            previewFocus={previewFocus}
            onNearestPillClick={(id) => {
              // Map pill tap = preview only (same as list card tap)
              handleNearestPreview(id)
            }}
            searchPin={
              searchLocation
                ? { lat: searchLocation.lat, lng: searchLocation.lng }
                : null
            }
            onSearchPinClick={openSearchSheet}
            route={routePlan?.drive ?? null}
            walkRoute={routePlan?.walk ?? null}
            navigating={Boolean(routePlan)}
            onNavigate={openSheet}
            onEvChargerSelect={openEvCharger}
            onBackgroundClick={dismissMapOverlays}
            onZoomChange={() => {}}
            onPreciseSpotsLoaded={setPreciseSpots}
            onStreetSpotsLoaded={setStreetSpots}
            onMapReady={() => setMapReady(true)}
            suppressedFeatureIds={suppressedIds}
            fullSpotIds={fullSpotIds}
            freeSpotIds={freeSpotIds}
            typeVerifications={typeVoteById}
            infoPanelOpen={Boolean(
              selected ||
                selectedEvCharger ||
                (searchSheetOpen && searchLocation) ||
                nearestPickerOpen ||
                draftPin ||
                editingPinId,
            )}
            cityId={cityId}
            myPins={myPins}
            draftPin={
              draftPin
                ? {
                    lat: draftPin.lat,
                    lng: draftPin.lng,
                    color: draftColorPreview,
                  }
                : null
            }
            editingPinId={editingPinId}
            pinDragEnabled={pinDragEnabled}
            onLongPress={handleLongPress}
            onMyPinClick={handleMyPinClick}
            onMyPinDragEnd={handleMyPinDragEnd}
          />
        </MapErrorBoundary>
        {!mapReady ? <MapChromeSkeleton /> : null}
      </div>

      <OfflineBanner />
      <PwaBanners />

      {/* Top search + filter chips — z-20 (below detail drawer z-30) */}
      <div
        className={`pointer-events-none absolute inset-x-0 top-0 z-20 px-3 pt-[max(0.65rem,env(safe-area-inset-top))] transition-opacity duration-200 sm:px-4 ${
          detailChromeOpen
            ? 'max-sm:pointer-events-none max-sm:opacity-0 max-sm:invisible'
            : ''
        }`}
        aria-hidden={detailChromeOpen ? true : undefined}
      >
        <div className="pointer-events-auto mx-auto w-full max-w-xl space-y-2">
          <div className="relative min-w-0">
            <div className={`${panel} overflow-hidden`}>
              <div className="flex min-w-0 items-center gap-1 px-2 py-1.5">
                <div className="relative min-w-0 flex-1 overflow-hidden">
                  {(geoLoading || pendingEnterSelect) &&
                  clampSearchQuery(query).length >= 3 ? (
                    <Loader2
                      className={`pointer-events-none absolute top-1/2 left-3 h-[18px] w-[18px] -translate-y-1/2 animate-spin ${muted}`}
                      strokeWidth={2.2}
                      aria-hidden
                    />
                  ) : (
                    <Search
                      className={`pointer-events-none absolute top-1/2 left-3 h-[18px] w-[18px] -translate-y-1/2 ${muted}`}
                      strokeWidth={2.2}
                    />
                  )}
                  <input
                    ref={searchInputRef}
                    role="combobox"
                    aria-expanded={isDropdownOpen}
                    aria-controls="search-suggestions"
                    aria-autocomplete="list"
                    aria-activedescendant={
                      isDropdownOpen &&
                      clampSearchQuery(query).length >= 3 &&
                      searchSuggestions[activeIndex]
                        ? suggestionOptionId(
                            searchSuggestions[activeIndex],
                            activeIndex,
                          )
                        : undefined
                    }
                    value={query}
                    onChange={(e) => {
                      skipNextGeocode.current = false
                      cancelPendingEnter()
                      const v = e.target.value.slice(0, 120)
                      setQuery(v)
                      const qLen = clampSearchQuery(v).length
                      setIsDropdownOpen(qLen >= 3 || myPins.length > 0)
                      if (qLen < 3) setMyPinsExpanded(false)
                    }}
                    onFocus={() => {
                      const q = clampSearchQuery(query).length
                      if (q >= 3 || myPins.length > 0) setIsDropdownOpen(true)
                    }}
                    onKeyDown={handleSearchKeyDown}
                    placeholder={t("search.placeholder")}
                    aria-label={t("search.aria")}
                    className={`w-full min-w-0 truncate rounded-2xl border-0 bg-transparent py-2.5 pr-10 pl-10 text-base font-sans outline-none sm:py-3 sm:text-lg ${text} placeholder:truncate placeholder:text-[#8E8E93]`}
                    autoComplete="off"
                    enterKeyHint="search"
                  />
                  {query ? (
                    <button
                      type="button"
                      onClick={() => {
                        skipNextGeocode.current = false
                        cancelPendingEnter()
                        setQuery('')
                        clearGeo()
                        setIsDropdownOpen(myPins.length > 0)
                      }}
                      className={`absolute top-1/2 right-2 -translate-y-1/2 cursor-pointer rounded-full p-1.5 ${muted} bg-black/5`}
                      aria-label={t("search.clear")}
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  ) : null}
                </div>
                <button
                  type="button"
                  data-testid="open-favorites"
                  onClick={() => setFavoritesOpen(true)}
                  className={`cursor-pointer rounded-full p-2.5 ${chip}`}
                  title={t("chrome.favorites")}
                  aria-label={t("chrome.favorites")}
                  aria-pressed={favoritesOpen}
                >
                  <Heart className="h-5 w-5" />
                </button>
                <button
                  type="button"
                  onClick={() => setInfoOpen(true)}
                  className={`cursor-pointer rounded-full p-2.5 ${chip}`}
                  title={t("chrome.rules")}
                  aria-label={t("chrome.rules")}
                >
                  <CircleHelp className="h-5 w-5" />
                </button>
                <button
                  type="button"
                  data-testid="open-privacy"
                  onClick={() => setPrivacyOpen(true)}
                  className={`cursor-pointer rounded-full p-2.5 ${chip}`}
                  title={t('chrome.privacy')}
                  aria-label={t('chrome.privacy')}
                  aria-pressed={privacyOpen}
                >
                  <Shield className="h-5 w-5" />
                </button>
                <button
                  type="button"
                  data-testid="open-teave"
                  onClick={() => setTeaveOpen(true)}
                  className={`cursor-pointer rounded-full p-2.5 ${chip}`}
                  title={t("chrome.teave")}
                  aria-label={t("chrome.teave")}
                  aria-pressed={teaveOpen}
                >
                  <Info className="h-5 w-5" />
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setTheme((t) => {
                      const next = toggleTheme(t)
                      persistTheme(next)
                      return next
                    })
                  }}
                  className={`cursor-pointer rounded-full p-2.5 ${chip}`}
                  title={dark ? t('chrome.themeLight') : t('chrome.themeDark')}
                  aria-label={dark ? t('chrome.themeToLight') : t('chrome.themeToDark')}
                >
                  {dark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
                </button>
              </div>
            </div>

            {isDropdownOpen &&
            (clampSearchQuery(query).length >= 3 || myPins.length > 0) ? (
              <div className="absolute inset-x-0 top-[calc(100%+0.4rem)] z-50">
                <SearchDropdown
                  loading={
                    (geoLoading || Boolean(pendingEnterSelect)) &&
                    searchSuggestions.length === 0 &&
                    clampSearchQuery(query).length >= 3
                  }
                  error={geoError}
                  suggestions={
                    clampSearchQuery(query).length >= 3 ? searchSuggestions : []
                  }
                  dark={dark}
                  onSelect={selectSearchSuggestion}
                  activeIndex={activeIndex}
                  onActiveIndexChange={setActiveIndex}
                  myPins={
                    clampSearchQuery(query).length < 3 ? myPins : undefined
                  }
                  myPinsExpanded={myPinsExpanded}
                  onExpandMyPins={() => setMyPinsExpanded(true)}
                />
              </div>
            ) : null}
          </div>

          {!isDropdownOpen ? (
            <div
              data-testid="filter-chips-wrap"
              className={`filter-chips-fade relative transition-opacity duration-200 ${
                detailChromeOpen
                  ? 'max-sm:pointer-events-none max-sm:h-0 max-sm:overflow-hidden max-sm:opacity-0'
                  : ''
              }`}
            >
              <div
                data-testid="filter-chips"
                className="no-scrollbar flex gap-2 overflow-x-auto px-0.5 py-0.5"
              >
                {FILTERS.map((f) => {
                  const active = filter === f.id
                  return (
                    <button
                      key={f.id}
                      type="button"
                      data-filter={f.id}
                      onClick={() => {
                        setFilter(f.id)
                        track('filter_used', { filter: f.id })
                        if (f.id === 'free_street') {
                          track('free_now_toggled', { filter: f.id })
                        }
                      }}
                      className={`tap-scale shrink-0 cursor-pointer rounded-full px-3.5 py-2 text-[13px] font-semibold shadow-sm sm:px-4 ${
                        active ? chipActive : `${panel} ${chip}`
                      }`}
                    >
                      {f.color && !active ? (
                        <span
                          className="mr-1.5 inline-block h-2 w-2 rounded-full align-middle"
                          style={{ backgroundColor: f.color }}
                        />
                      ) : null}
                      {f.label}
                    </button>
                  )
                })}
              </div>
            </div>
          ) : null}

          {/* Below filters only when detail panel is closed — never overlays pills */}
          {routeSummaryReady && routePlan && !selected ? (
            <div
              data-testid="route-summary"
              className={`pointer-events-auto w-full animate-fade-in px-3 py-2.5 ${panel}`}
              role="status"
              aria-live="polite"
            >
              <div className="flex items-start gap-3">
                <div className="min-w-0 flex-1 space-y-1.5">
                  <p className={`truncate text-[13px] font-semibold ${text}`}>
                    {routePlan.label}
                  </p>
                  {routePlan.drive ? (
                    <p
                      className={`flex items-center gap-1.5 text-[12px] font-semibold ${
                        dark ? 'text-[#64D2FF]' : 'text-[#007AFF]'
                      }`}
                    >
                      <Car className="h-3.5 w-3.5 shrink-0" aria-hidden />
                      <span>{t('route.byCar')}</span>
                      <span className={muted}>
                        {formatDistance(routePlan.drive.distanceMeters)}
                        {' · '}
                        {formatDuration(routePlan.drive.durationSeconds)}
                      </span>
                    </p>
                  ) : null}
                  {routePlan.walk ? (
                    <p
                      className={`flex flex-wrap items-center gap-1.5 text-[12px] font-semibold ${
                        routePlan.walk.isFallback
                          ? muted
                          : dark
                            ? 'text-[#FF9F0A]'
                            : 'text-[#FF9500]'
                      }`}
                    >
                      <Footprints className="h-3.5 w-3.5 shrink-0" aria-hidden />
                      <span>
                        {routePlan.walk.isFallback
                          ? t('route.approxWalk')
                          : t('route.onFoot')}
                      </span>
                      <span className={muted}>
                        {formatDistance(routePlan.walk.distanceMeters)}
                        {' · '}
                        {formatDuration(routePlan.walk.durationSeconds)}
                      </span>
                      {routePlan.longWalk ? (
                        <span
                          className={`rounded-md px-1.5 py-0.5 text-[12px] font-bold ${
                            dark
                              ? 'bg-[#FF9F0A]/20 text-[#FF9F0A]'
                              : 'bg-[#FF9500]/15 text-[#C93400]'
                          }`}
                        >
                          {t('route.longWalk')}
                        </span>
                      ) : null}
                    </p>
                  ) : null}
                  {routePlan.drive || routePlan.walk ? (
                    <p className={`text-[12px] font-medium ${muted}`}>
                      {t('route.totalApprox', {
                        duration: formatDuration(
                          (routePlan.drive?.durationSeconds ?? 0) +
                            (routePlan.walk?.durationSeconds ?? 0),
                        ),
                      })}
                    </p>
                  ) : null}
                </div>
                <button
                  type="button"
                  onClick={clearRoute}
                  className={`tap-scale flex h-11 w-11 shrink-0 items-center justify-center rounded-full ${chip} focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#007AFF]`}
                  aria-label={t("chrome.hideRoute")}
                  title={t("chrome.hideRoute")}
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>
          ) : null}
        </div>
      </div>

      {/* FABs — z-10; fade away on mobile when detail sheet is open */}
      <div
        data-testid="map-fabs"
        className={`absolute right-3 z-10 flex flex-col gap-2.5 transition-opacity duration-200 sm:right-4 bottom-[max(6.5rem,env(safe-area-inset-bottom))] ${
          detailChromeOpen
            ? 'max-sm:pointer-events-none max-sm:opacity-0 max-sm:invisible sm:bottom-[max(6.5rem,env(safe-area-inset-bottom))]'
            : ''
        }`}
        aria-hidden={detailChromeOpen ? true : undefined}
      >
        <button
          type="button"
          data-testid="locate-me"
          onClick={() => {
            void locateMe()
          }}
          disabled={gpsLocating}
          className={fabClass}
          title={followUser ? t('chrome.locateFollow') : t('chrome.locateTitle')}
          aria-label={followUser ? t('chrome.locateFollow') : t('chrome.locate')}
          aria-pressed={followUser}
          aria-busy={gpsLocating}
        >
          {gpsLocating ? (
            <Loader2 className="h-[22px] w-[22px] animate-spin text-[#007AFF]" />
          ) : (
            <LocateFixed
              className={`h-[22px] w-[22px] ${
                followUser
                  ? 'text-[#007AFF]'
                  : hasGps
                    ? 'text-[#007AFF]/80'
                    : muted
              }`}
            />
          )}
        </button>
        <button
          type="button"
          onClick={() => setPitch3d((v) => !v)}
          className={fabClass}
          title={pitch3d ? t('chrome.view2d') : t('chrome.view3d')}
          aria-label={pitch3d ? t('chrome.view2d') : t('chrome.view3d')}
        >
          {pitch3d ? (
            <MapIcon className="h-[22px] w-[22px] text-[#007AFF]" />
          ) : (
            <Box className="h-[22px] w-[22px] text-[#007AFF]" />
          )}
        </button>
        <button
          type="button"
          onClick={() => {
            if (timerOpen) closeSessionModal()
            else openSessionModal()
          }}
          className={`relative ${fabClass}`}
          title={activeSession ? t('chrome.activeSession') : t('chrome.parkingClock')}
          aria-label={activeSession ? t('chrome.activeSession') : t('chrome.parkingClock')}
          aria-expanded={timerOpen}
        >
          <Clock3 className={`h-[22px] w-[22px] ${activeSession ? 'text-[#34C759]' : muted}`} />
          {activeSession ? (
            <span className="absolute top-2 right-2 h-2 w-2 rounded-full bg-[#34C759] ring-2 ring-white" />
          ) : null}
        </button>
        <button
          type="button"
          onClick={openProposeNew}
          className="tap-scale flex h-[52px] w-[52px] items-center justify-center rounded-full bg-[#34C759] text-white shadow-[0_4px_16px_rgba(52,199,89,0.35)]"
          title={t("chrome.proposeSpotTitle")}
          aria-label={t("chrome.proposeSpot")}
        >
          <Plus className="h-6 w-6" strokeWidth={2.4} />
        </button>
      </div>

      {/* Isolated clock-FAB session modal — never stacks in the left detail rail */}
      {timerOpen && !selected && !selectedEvCharger ? (
        <ParkingSessionModal
          dark={dark}
          timerSeconds={timerSeconds}
          timerMode={timerMode}
          timerLabel={timerLabel}
          sessionLoading={sessionLoading}
          sessionAction={sessionAction}
          activeSession={activeSession}
          sessionNotice={sessionNotice}
          priceEstimate={priceEstimate}
          selectedSpot={null}
          onClose={closeSessionModal}
          onStart={() => {
            void beginParkingSession()
          }}
          onStop={() => {
            void endParkingSession()
          }}
          onStatus={() => {
            void refreshParkingStatus()
          }}
          onExtend={(mins) => {
            void addPrepaidMinutes(mins)
          }}
          formatHourlyRate={formatHourlyRate}
          formatSessionInstant={formatSessionInstant}
          onOpenPrivacy={() => setPrivacyOpen(true)}
        />
      ) : null}
      {connectionNotice && !selected && !timerOpen ? (
        <p
          data-testid="connection-notice"
          className={`pointer-events-none absolute bottom-[max(5.5rem,env(safe-area-inset-bottom))] left-1/2 z-40 max-w-[min(90vw,20rem)] -translate-x-1/2 rounded-full px-3 py-1.5 text-center text-[12px] font-semibold ${
            dark ? 'bg-black/50 text-white/80' : 'bg-white/80 text-[#636366]'
          }`}
        >
          {connectionNotice}
        </p>
      ) : null}

      {selectedEvCharger && !selected ? (
        <EvChargerSheet
          feature={selectedEvCharger}
          dark={dark}
          onClose={() => setSelectedEvCharger(null)}
        />
      ) : null}

      {favoritesOpen && !selected && !selectedEvCharger ? (
        <FavoritesPanel
          spots={allSpots}
          dark={dark}
          draftLocation={
            searchLocation
              ? {
                  lat: searchLocation.lat,
                  lng: searchLocation.lng,
                  name: searchLocation.name,
                  address: searchLocation.label,
                  label: searchLocation.label,
                }
              : null
          }
          onClose={() => setFavoritesOpen(false)}
          onSelect={(spot) => {
            setFavoritesOpen(false)
            setSelectedEvCharger(null)
            setSelected(spot)
            setFlyMode('fly')
            setFlyTarget([spot.lat, spot.lng])
            setFlyZoom(16)
            setFlyKey((k) => k + 1)
          }}
          onSelectPlace={(place) => {
            setFavoritesOpen(false)
            setSelectedEvCharger(null)
            flyToDestination({
              id: `saved-${place.kind}`,
              name: place.name,
              label: place.address || place.name,
              lat: place.lat,
              lng: place.lng,
              kind: place.kind,
            })
          }}
        />
      ) : null}

      {selectedDisplay ? (
        <ParkingDetailPanel
          spot={selectedDisplay}
          distanceLabel={selectedDist}
          sessionLoading={sessionLoading}
          sessionAction={sessionAction}
          activeSession={activeSession}
          sessionNotice={sessionNotice}
          priceEstimate={priceEstimate}
          routeSummary={
            routeSummaryReady && routePlan
              ? {
                  label: routePlan.label,
                  driveDistanceM: routePlan.drive?.distanceMeters ?? 0,
                  driveDurationS: routePlan.drive?.durationSeconds ?? 0,
                  walkDistanceM: routePlan.walk?.distanceMeters,
                  walkDurationS: routePlan.walk?.durationSeconds,
                  walkIsFallback: routePlan.walk?.isFallback,
                  longWalk: routePlan.longWalk,
                }
              : null
          }
          onClearRoute={routePlan ? clearRoute : undefined}
          dark={dark}
          onClose={() => {
            setFromNearestPicker(false)
            closeSheet()
          }}
          onBackToList={
            fromNearestPicker && nearestOptions.length > 0
              ? handleBackToNearestList
              : undefined
          }
          onStartSession={() => {
            void beginParkingSession()
          }}
          onStopSession={() => {
            void endParkingSession()
          }}
          onCheckStatus={() => {
            // Async status fetch only — no navigation / reload
            void refreshParkingStatus()
          }}
          onExtendMinutes={(mins) => {
            void addPrepaidMinutes(mins)
          }}
          onReportInvalid={() => openReportInvalid(selectedDisplay)}
          alternatives={alternatives}
          noAlternatives={noAlternatives}
          isFull={fullSpotIds.has(selectedDisplay.id)}
          communityReportLabel={formatCommunityReportLabel(
            getReport(selectedDisplay.id),
          )}
          reportCooldownActive={!canSubmitReport(selectedDisplay.id)}
          onFindAnother={handleFindAnother}
          onMarkFull={handleMarkFull}
          onCrowdReportSuccess={handleCrowdReportSuccess}
          onWidenRadius={handleWidenRadius}
          onSelectAlternative={handleSelectAlternative}
          onAbuseReportResult={(ok, message) => {
            setToast({
              kind: ok ? 'info' : 'error',
              title: ok ? t('toasts.feedbackThanks') : t('toasts.feedbackFail'),
              detail: message,
            })
          }}
        />
      ) : null}

      {nearestPickerOpen && searchLocation && !selected && !selectedEvCharger ? (
        <NearestParkingPanel
          targetName={searchLocation.name || searchLocation.label}
          options={nearestOptions}
          dark={dark}
          selectedPreviewId={selectedPreviewId}
          onPreview={handleNearestPreview}
          onConfirm={handleNearestConfirm}
          onVisibleOptionsChange={setNearestVisibleKeys}
          onWidenRadius={handleNearestWidenRadius}
          canWidenRadius={nearestRadiusM < NEAREST_MAX_RADIUS_M}
          onClose={() => {
            setNearestPickerOpen(false)
            setSelectedPreviewId(null)
            setNearestVisibleKeys(null)
            setNearestRadiusM(NEAREST_DEFAULT_RADIUS_M)
            setSearchSheetOpen(true)
          }}
        />
      ) : null}

      {searchSheetOpen &&
      searchLocation &&
      !selected &&
      !selectedEvCharger &&
      !nearestPickerOpen ? (
        <LocationInfoSheet
          location={searchLocation}
          dark={dark}
          onClose={() => setSearchSheetOpen(false)}
          onClear={clearSearchLocation}
          alternatives={alternatives}
          noAlternatives={noAlternatives}
          onFindNearest={handleFindAnother}
          onWidenRadius={handleWidenRadius}
          onSelectAlternative={handleSelectAlternative}
        />
      ) : null}

      {draftPin || editingPinId ? (
        <MyPinSheet
          key={editingPinId ?? `draft-${draftPin?.lat}-${draftPin?.lng}`}
          mode={editingPinId ? 'edit' : 'create'}
          draft={draftPin}
          pin={
            editingPinId
              ? myPins.find((p) => p.id === editingPinId) ?? null
              : null
          }
          dark={dark}
          onClose={closePinSheet}
          onSave={(payload) => {
            if (editingPinId) {
              handleUpdatePin(editingPinId, payload)
            } else {
              handleCreatePin(payload)
            }
          }}
          onDelete={
            editingPinId
              ? () => handleDeletePin(editingPinId)
              : undefined
          }
          onNavigate={
            editingPinId
              ? () => {
                  const pin = myPins.find((p) => p.id === editingPinId)
                  if (pin) navigateToMyPin(pin)
                }
              : undefined
          }
          onColorPreview={(c) => {
            setDraftColorPreview(c)
            if (draftPin) setDraftPin({ ...draftPin, color: c })
          }}
          onDragRequest={setPinDragEnabled}
        />
      ) : null}

      <Toast toast={toast} onClose={dismissToast} />

      {teaveOpen ? (
        <TeavePanel
          onClose={() => setTeaveOpen(false)}
          onOpenPrivacy={() => {
            setTeaveOpen(false)
            setPrivacyOpen(true)
          }}
        />
      ) : null}

      {privacyOpen ? (
        <PrivacyPanel onClose={() => setPrivacyOpen(false)} />
      ) : null}

      {infoOpen ? (
        <ModalShell
          onClose={() => setInfoOpen(false)}
          title={
            cityId === 'parnu' ? t('rules.parnu') : t('rules.tallinn')
          }
        >
          <div className="max-h-[60vh] space-y-3 overflow-y-auto text-xs leading-relaxed text-ink-soft">
            {cityId === 'parnu' ? (
              <>
                {PARNU_ZONE_LIST.map((z) => (
                  <div key={z.id} className="rounded-2xl bg-paper-2 p-3">
                    <h4 className="mb-1 text-sm font-bold text-ink">{z.name}</h4>
                    <p>
                      • {z.pricePerHour.toFixed(0)} €/h · {z.pricePer24h.toFixed(0)} €/24h
                    </p>
                    <p>• {t('rules.discFree', { n: z.freeMinutesWithDisc })}</p>
                    <p className="mt-1 text-[12px] opacity-80">{z.source}</p>
                  </div>
                ))}
                <div className="rounded-2xl border border-moss/20 bg-moss/8 p-3">
                  <h4 className="mb-1 text-sm font-bold text-moss">Vabastused</h4>
                  <p>• Täis-elektriline M1 sõiduauto</p>
                  <p>• Mootorrattad</p>
                  <p>• Invakaardi omanikud</p>
                </div>
                <p className="text-[12px] opacity-70">
                  Kontrolli kohapealt silti. Andmed: OSM + parnu.ee/parkimine.
                </p>
              </>
            ) : (
              <>
            <div className="rounded-2xl border border-sea/20 bg-sea/8 p-3">
              <h4 className="mb-1 text-sm font-bold text-sea">{t('rules.first15')}</h4>
              <p>
                {t('rules.first15Body')}
              </p>
              <p className="mt-1.5 text-[12px] opacity-90">
                {t('rules.first15Note')}
              </p>
            </div>
            <div className="rounded-2xl bg-paper-2 p-3">
              <h4 className="mb-1 text-sm font-bold text-ink">{t('rules.zonePrices')}</h4>
              <p className="mb-2 text-[12px] opacity-80">
                {t('rules.zonePricesHint')}
              </p>
              {ZONE_RATE_LIST.map((z) => (
                <p key={z.code}>
                  • {zoneName(z.code)} — {String(z.pricePerMinute).replace('.', ',')} €/min (
                  {formatMoney(z.pricePerHour)}/h) · {z.hoursNote}
                  {z.freeMinutes > 0 ? ` · ${t('rules.minFree', { n: z.freeMinutes })}` : ''}
                </p>
              ))}
            </div>
            <div className="rounded-2xl bg-paper-2 p-3">
              <h4 className="mb-1 text-sm font-bold text-ink">{t('rules.freeHours')}</h4>
              <p>• {t('rules.freeHoursWeekday')}</p>
              <p>• {t('rules.freeHoursSaturday')}</p>
              <p>• {t('rules.freeHoursSunday')}</p>
            </div>
              </>
            )}
            <div className="rounded-2xl border border-moss/20 bg-moss/8 p-3">
              <h4 className="mb-1 text-sm font-bold text-moss">{t('rules.mapLegend')}</h4>
              <p>
                {t('rules.mapLegendBody')}
              </p>
            </div>
            <div className="rounded-2xl bg-paper-2 p-3">
              <h4 className="mb-1 text-sm font-bold text-ink">
                {t('rules.myPinsTitle', { n: myPins.length })}
              </h4>
              <p>
                {t('rules.myPinsBody')}
              </p>
            </div>
          </div>
        </ModalShell>
      ) : null}

      {reportContext ? (
        <ReportModal
          context={reportContext}
          onClose={() => setReportContext(null)}
          onSubmitted={(message, ok = true) => {
            setToast({
              kind: ok ? 'info' : 'error',
              title: ok ? t('toasts.feedbackThanks') : t('toasts.feedbackFail'),
              detail: message,
            })
            if (ok && reportContext?.mode === 'PROPOSE_NEW') {
              track('spot_added', { mode: 'PROPOSE_NEW' })
            }
          }}
        />
      ) : null}

    </div>
  )
}
